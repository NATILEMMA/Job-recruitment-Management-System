﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CSharpProject
{
	public partial class Login : Form
	{
		SqlDataReader sdr;
		string connString = @"Data Source=ናቲ;Initial Catalog=formloginDB;Integrated Security=True";
		public Login()
		{
			InitializeComponent();
		}

		private void label1_Click(object sender, EventArgs e)
		{

		}

		private void Form1_Load(object sender, EventArgs e)
		{

		}

		private void pictureBox1_Click(object sender, EventArgs e)
		{

		}

		private void richTextBox1_TextChanged(object sender, EventArgs e)
		{

		}
	private void button1_Click(object sender, EventArgs e)
		{
			this.Hide();
			signUp signup = new signUp();
			signup.Show();
		}
	

		private void loginBtn_Click(object sender, EventArgs e)
		{
			SqlConnection sqc = new SqlConnection(connString);
				sqc.Open();
				SqlCommand cmd;
				SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(" select count(*) from userTb where userName = '" + userNameTxtF.Text+"' and password = '"+passwordTxtF.Text+"' ",sqc);
				DataTable tb = new DataTable();
				sqlDataAdapter.Fill(tb);
				sqlDataAdapter.Dispose();
				sqc.Close();

				sqc.Open();
				Console.WriteLine(userNameTxtF.Text);
				cmd = new SqlCommand("select Id ,userName from userTb where userName ='" + userNameTxtF.Text.Trim()+"'", sqc);
				sdr = cmd.ExecuteReader();
				
				if (tb.Rows[0][0].ToString() == "1") {
					if (sdr.Read())
					{
						int accountId = int.Parse(sdr[0].ToString());
						String AccountUserName = sdr[1].ToString();

						Forms.settingsForm.setAccountId(accountId);
						UserForm.setUserName(AccountUserName);
					    applicationListSubForm.Add.setAccountId(accountId);
						Forms.statusCatagoryForm.setAccountId(accountId);
						Forms.vaccancyForm.setAccountId(accountId);


						settingsSubForm.Change_user_name_and_password.setAccountId(accountId);
					    cmd.Dispose();
						sdr.Close();
						sqc.Close();
				}
				else
				{
					cmd.Dispose();
					sdr.Close();
					sqc.Close();
				}
					this.Hide();
					UserForm adminform = new UserForm();
					adminform.Show();
					
		        }
				else
				{
					MessageBox.Show("Incorrect User Name and Password combination.","Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					sqc.Close();
					cmd.Dispose();

				}
		}
			
		private void exit_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void userNameTxtF_TextChanged(object sender, EventArgs e)
		{

		}
	}
}
