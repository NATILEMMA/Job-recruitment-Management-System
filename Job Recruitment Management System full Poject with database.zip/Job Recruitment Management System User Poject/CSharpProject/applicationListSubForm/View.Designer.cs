﻿
namespace CSharpProject.applicationListSubForm
{
	partial class View
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label2 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.updateBtn = new System.Windows.Forms.Button();
			this.positionTb = new System.Windows.Forms.TextBox();
			this.register = new System.Windows.Forms.Button();
			this.coverLetterTb = new System.Windows.Forms.TextBox();
			this.addressTb = new System.Windows.Forms.TextBox();
			this.isFemalRb = new System.Windows.Forms.RadioButton();
			this.isMaleRb = new System.Windows.Forms.RadioButton();
			this.fatherNameTb = new System.Windows.Forms.TextBox();
			this.lastNameTb = new System.Windows.Forms.TextBox();
			this.email = new System.Windows.Forms.TextBox();
			this.phoneNumberTb = new System.Windows.Forms.TextBox();
			this.firstNameTb = new System.Windows.Forms.TextBox();
			this.label12 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(388, 478);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(61, 16);
			this.label2.TabIndex = 78;
			this.label2.Text = "Resume:";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(464, 475);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(107, 23);
			this.button1.TabIndex = 77;
			this.button1.Text = "Open with Adobe";
			this.button1.UseVisualStyleBackColor = true;
			// 
			// updateBtn
			// 
			this.updateBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.updateBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.updateBtn.ForeColor = System.Drawing.Color.DarkMagenta;
			this.updateBtn.Location = new System.Drawing.Point(597, 562);
			this.updateBtn.Name = "updateBtn";
			this.updateBtn.Size = new System.Drawing.Size(75, 23);
			this.updateBtn.TabIndex = 76;
			this.updateBtn.Text = "Update";
			this.updateBtn.UseVisualStyleBackColor = false;
			// 
			// positionTb
			// 
			this.positionTb.Location = new System.Drawing.Point(15, 52);
			this.positionTb.Name = "positionTb";
			this.positionTb.Size = new System.Drawing.Size(161, 20);
			this.positionTb.TabIndex = 75;
			// 
			// register
			// 
			this.register.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
			this.register.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.register.ForeColor = System.Drawing.Color.Red;
			this.register.Location = new System.Drawing.Point(701, 562);
			this.register.Name = "register";
			this.register.Size = new System.Drawing.Size(75, 23);
			this.register.TabIndex = 74;
			this.register.Text = "Exit";
			this.register.UseVisualStyleBackColor = false;
			// 
			// coverLetterTb
			// 
			this.coverLetterTb.Location = new System.Drawing.Point(374, 52);
			this.coverLetterTb.Multiline = true;
			this.coverLetterTb.Name = "coverLetterTb";
			this.coverLetterTb.Size = new System.Drawing.Size(405, 365);
			this.coverLetterTb.TabIndex = 73;
			// 
			// addressTb
			// 
			this.addressTb.Location = new System.Drawing.Point(10, 439);
			this.addressTb.Multiline = true;
			this.addressTb.Name = "addressTb";
			this.addressTb.Size = new System.Drawing.Size(254, 55);
			this.addressTb.TabIndex = 72;
			// 
			// isFemalRb
			// 
			this.isFemalRb.AutoSize = true;
			this.isFemalRb.Location = new System.Drawing.Point(128, 316);
			this.isFemalRb.Name = "isFemalRb";
			this.isFemalRb.Size = new System.Drawing.Size(59, 17);
			this.isFemalRb.TabIndex = 71;
			this.isFemalRb.TabStop = true;
			this.isFemalRb.Text = "Female";
			this.isFemalRb.UseVisualStyleBackColor = true;
			// 
			// isMaleRb
			// 
			this.isMaleRb.AutoSize = true;
			this.isMaleRb.Location = new System.Drawing.Point(74, 316);
			this.isMaleRb.Name = "isMaleRb";
			this.isMaleRb.Size = new System.Drawing.Size(48, 17);
			this.isMaleRb.TabIndex = 70;
			this.isMaleRb.TabStop = true;
			this.isMaleRb.Text = "Male";
			this.isMaleRb.UseVisualStyleBackColor = true;
			// 
			// fatherNameTb
			// 
			this.fatherNameTb.Location = new System.Drawing.Point(15, 161);
			this.fatherNameTb.Name = "fatherNameTb";
			this.fatherNameTb.Size = new System.Drawing.Size(161, 20);
			this.fatherNameTb.TabIndex = 69;
			// 
			// lastNameTb
			// 
			this.lastNameTb.Location = new System.Drawing.Point(10, 223);
			this.lastNameTb.Name = "lastNameTb";
			this.lastNameTb.Size = new System.Drawing.Size(161, 20);
			this.lastNameTb.TabIndex = 68;
			// 
			// email
			// 
			this.email.Location = new System.Drawing.Point(10, 280);
			this.email.Name = "email";
			this.email.Size = new System.Drawing.Size(161, 20);
			this.email.TabIndex = 67;
			// 
			// phoneNumberTb
			// 
			this.phoneNumberTb.Location = new System.Drawing.Point(10, 377);
			this.phoneNumberTb.Name = "phoneNumberTb";
			this.phoneNumberTb.Size = new System.Drawing.Size(161, 20);
			this.phoneNumberTb.TabIndex = 66;
			// 
			// firstNameTb
			// 
			this.firstNameTb.Location = new System.Drawing.Point(15, 109);
			this.firstNameTb.Name = "firstNameTb";
			this.firstNameTb.Size = new System.Drawing.Size(161, 20);
			this.firstNameTb.TabIndex = 65;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label12.Location = new System.Drawing.Point(12, 90);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(78, 16);
			this.label12.TabIndex = 64;
			this.label12.Text = "First Name";
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label11.Location = new System.Drawing.Point(12, 142);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(91, 16);
			this.label11.TabIndex = 63;
			this.label11.Text = "Father Name";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label10.Location = new System.Drawing.Point(12, 194);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(74, 16);
			this.label10.TabIndex = 62;
			this.label10.Text = "Last Name";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label9.Location = new System.Drawing.Point(12, 316);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(56, 16);
			this.label9.TabIndex = 61;
			this.label9.Text = "Gender";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8.Location = new System.Drawing.Point(12, 256);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(43, 16);
			this.label8.TabIndex = 60;
			this.label8.Text = "Email";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.Location = new System.Drawing.Point(7, 348);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(158, 16);
			this.label7.TabIndex = 59;
			this.label7.Text = "Contact Phone number";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.Location = new System.Drawing.Point(9, 412);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(59, 16);
			this.label6.TabIndex = 58;
			this.label6.Text = "Address";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.Location = new System.Drawing.Point(371, 24);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(90, 16);
			this.label5.TabIndex = 57;
			this.label5.Text = "Cover Letter";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(12, 24);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(60, 16);
			this.label1.TabIndex = 56;
			this.label1.Text = "Position";
			// 
			// View
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.ClientSize = new System.Drawing.Size(821, 592);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.updateBtn);
			this.Controls.Add(this.positionTb);
			this.Controls.Add(this.register);
			this.Controls.Add(this.coverLetterTb);
			this.Controls.Add(this.addressTb);
			this.Controls.Add(this.isFemalRb);
			this.Controls.Add(this.isMaleRb);
			this.Controls.Add(this.fatherNameTb);
			this.Controls.Add(this.lastNameTb);
			this.Controls.Add(this.email);
			this.Controls.Add(this.phoneNumberTb);
			this.Controls.Add(this.firstNameTb);
			this.Controls.Add(this.label12);
			this.Controls.Add(this.label11);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label1);
			this.Location = new System.Drawing.Point(500, 100);
			this.Name = "View";
			this.Text = "View";
			this.Load += new System.EventHandler(this.View_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button updateBtn;
		private System.Windows.Forms.TextBox positionTb;
		private System.Windows.Forms.Button register;
		private System.Windows.Forms.TextBox coverLetterTb;
		private System.Windows.Forms.TextBox addressTb;
		private System.Windows.Forms.RadioButton isFemalRb;
		private System.Windows.Forms.RadioButton isMaleRb;
		private System.Windows.Forms.TextBox fatherNameTb;
		private System.Windows.Forms.TextBox lastNameTb;
		private System.Windows.Forms.TextBox email;
		private System.Windows.Forms.TextBox phoneNumberTb;
		private System.Windows.Forms.TextBox firstNameTb;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label1;
	}
}