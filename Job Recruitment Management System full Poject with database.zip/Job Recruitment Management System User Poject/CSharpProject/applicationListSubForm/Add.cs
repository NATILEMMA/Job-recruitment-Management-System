﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.IO;

namespace CSharpProject.applicationListSubForm
{
	public partial class Add : Form
	{
		SqlConnection conn;
		SqlCommand scmd;
		SqlDataAdapter sda;
		SqlDataReader dreader;
		String connString = @"Data Source=ናቲ;Initial Catalog=formloginDB;Integrated Security=True";
		string Gender = "";
		string Status = "New";
		String JobTitle, Company;
		string file;
		string fileName;
		string dest;
		int VaccancyId;
		static int accountId;

		public Add(String JobTitle, String Company, int VaccancyId)
		{
			this.JobTitle = JobTitle;
			this.Company = Company;
			this.VaccancyId = VaccancyId;

			InitializeComponent();

		}

		public static void setAccountId(int AccountId)
		{
			accountId = AccountId;
		}

		private void label10_Click(object sender, EventArgs e)
		{

		}

		private void textBox10_TextChanged(object sender, EventArgs e)
		{

		}

		private void textBox5_TextChanged(object sender, EventArgs e)
		{

		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		private void radioButton1_CheckedChanged(object sender, EventArgs e)
		{
			Gender = "Male";

		}

		private void radioButton2_CheckedChanged(object sender, EventArgs e)
		{
			Gender = "Female";
		}


		private void Add_Load(object sender, EventArgs e)
		{
			//on load
			jobTitlelbl.Text = JobTitle;
			companyLbl.Text = Company;
			vaccancyIdLbl.Text = VaccancyId.ToString();

			conn = new SqlConnection(connString);
			conn.Open();
			scmd = new SqlCommand("select* from userTb where Id =" + accountId + " ", conn);

			try
			{
				dreader = scmd.ExecuteReader();
				if (dreader.Read())
				{

					firstNameLbl.Text = dreader[0].ToString().Trim();
					fatherNameLbl.Text = dreader[1].ToString().Trim();
					lastNameLbl.Text = dreader[2].ToString().Trim();
					genderLbl.Text = dreader[3].ToString().Trim();
					phoneNumberLbl.Text = dreader[4].ToString().Trim();
					AddressLbl.Text = dreader[5].ToString().Trim();
				}
			}
			catch (Exception)
			{
				MessageBox.Show(" not record");
			}
			finally { conn.Close(); }

		}

		private void StoreFile()
		{
			File.Copy(file, dest, true);
			MessageBox.Show("success");
		}



		private void button1_Validating(object sender, CancelEventArgs e)
		{


		}

		private void button1_Click(object sender, EventArgs e)
		{
			//browse button
			DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog.
			if (result == DialogResult.OK) // Test result.
			{
				file = openFileDialog1.FileName;

				filePathTb.Text = file;

				string[] f = file.Split('\\');
				// to get the only file name
				fileName = f[(f.Length) - 1];
				dest = @"C:\Users\NatPro\source\repos\CSharpProject\Resume\" + fileName;
			}
		}

		private void emailTb_Validating_1(object sender, CancelEventArgs e)
		{
			emailValidator();
		}
		public bool emailValidator()
		{
			if (string.IsNullOrEmpty(emailTb.Text))
			{
				errorProvider1.SetError(emailTb, "This box should not be empty!!!");
				return false;
			}
			else if ((emailTb.Text.IndexOf("@")) == -1)
			{

				errorProvider1.SetError(emailTb, " The email provided should contain '@' symbole");
				return false;
			}
			else
			{

				errorProvider1.SetError(emailTb, null);
				return true;
			}
		}

		public bool coverletterValidator()
		{
			//cover letter validating
			if (string.IsNullOrEmpty(coverLetterTb.Text))
			{

				errorProvider1.SetError(coverLetterTb, "This box should not be empty");
				return false;
			}
			else
			{

				errorProvider1.SetError(coverLetterTb, null);
				return true;
			}

		}



		public bool filePathValidator()
		{
			// file path validating

			if (string.IsNullOrEmpty(filePathTb.Text))
			{
				errorProvider1.SetError(filePathTb, "This box should not be empty");
				return false;
			}
			else if (!((filePathTb.Text.EndsWith(".pdf")) || (filePathTb.Text.EndsWith(".PDF"))))
			{
				errorProvider1.SetError(filePathTb, "The file selected should be in '.pdf' format!!!");
				return false;
			}
			else
			{
				errorProvider1.SetError(filePathTb, null);
				return true;
			}

		}

		private void coverLetterTb_Validating_1(object sender, CancelEventArgs e)
		{
			coverletterValidator();
		}

		private void filePathTb_TextChanged(object sender, EventArgs e)
		{

		}

		private void filePathTb_Validating_1(object sender, CancelEventArgs e)
		{
			filePathValidator();
		}

		private void label2_Click(object sender, EventArgs e)
		{

		}

		private void register_Click_1(object sender, EventArgs e)
		{
			//submit button
			bool emailVerified = emailValidator();
			bool filepathVerified = filePathValidator();
			bool coverletterVerified = coverletterValidator();

			if (emailVerified == true && filepathVerified == true && coverletterVerified == true)
			{

				using (SqlConnection sqc = new SqlConnection(connString))
				{

					sqc.Open();

					SqlCommand cmd = new SqlCommand("standardPInsertApplicationsForm", sqc);
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.Parameters.AddWithValue("@firstName", firstNameLbl.Text.Trim());
					cmd.Parameters.AddWithValue("@fatherName", fatherNameLbl.Text.Trim());
					cmd.Parameters.AddWithValue("@lastName", lastNameLbl.Text.Trim());
					cmd.Parameters.AddWithValue("@gender", genderLbl.Text.Trim());
					cmd.Parameters.AddWithValue("@email", emailTb.Text.Trim());
					cmd.Parameters.AddWithValue("@contactPhoneNumber", phoneNumberLbl.Text.Trim());
					cmd.Parameters.AddWithValue("@address", AddressLbl.Text.Trim());
					cmd.Parameters.AddWithValue("@coverLetter", coverLetterTb.Text.Trim());
					cmd.Parameters.AddWithValue("@status", Status.Trim());
					cmd.Parameters.AddWithValue("@position", jobTitlelbl.Text.Trim());
					cmd.Parameters.AddWithValue("@company", companyLbl.Text.Trim());
					cmd.Parameters.AddWithValue("@JobTitle", jobTitlelbl.Text.Trim());
					cmd.Parameters.AddWithValue("@VaccancyId", int.Parse(vaccancyIdLbl.Text.Trim()));
					cmd.Parameters.AddWithValue("@fileName", fileName);
					cmd.Parameters.AddWithValue("@filePath", dest);
					cmd.Parameters.AddWithValue("@Mail", "No Mail.");
					cmd.Parameters.AddWithValue("userId",accountId);

					cmd.ExecuteNonQuery();
					sqc.Close();
					StoreFile();
					MessageBox.Show("Application submition was successfull !!! ", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
					this.Close();
				}
			}
		}

	}
}
