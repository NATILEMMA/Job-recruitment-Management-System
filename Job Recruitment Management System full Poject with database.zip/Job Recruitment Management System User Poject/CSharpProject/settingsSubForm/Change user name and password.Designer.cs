﻿
namespace CSharpProject.settingsSubForm
{
	partial class Change_user_name_and_password
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label3 = new System.Windows.Forms.Label();
			this.confirmationPasswordTxtB = new System.Windows.Forms.TextBox();
			this.changeBtn = new System.Windows.Forms.Button();
			this.register = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.confirmPasswordTxtB = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.newPasswordTxtB = new System.Windows.Forms.TextBox();
			this.passwordMandatoryLbl = new System.Windows.Forms.Label();
			this.newPasswordFieldEmptyErrorLbl = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label3.Location = new System.Drawing.Point(88, 102);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(117, 19);
			this.label3.TabIndex = 91;
			this.label3.Text = "Old password";
			// 
			// confirmationPasswordTxtB
			// 
			this.confirmationPasswordTxtB.Location = new System.Drawing.Point(222, 103);
			this.confirmationPasswordTxtB.Name = "confirmationPasswordTxtB";
			this.confirmationPasswordTxtB.Size = new System.Drawing.Size(254, 20);
			this.confirmationPasswordTxtB.TabIndex = 90;
			// 
			// changeBtn
			// 
			this.changeBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.changeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.changeBtn.ForeColor = System.Drawing.Color.DarkMagenta;
			this.changeBtn.Location = new System.Drawing.Point(108, 321);
			this.changeBtn.Name = "changeBtn";
			this.changeBtn.Size = new System.Drawing.Size(104, 39);
			this.changeBtn.TabIndex = 89;
			this.changeBtn.Text = "Change";
			this.changeBtn.UseVisualStyleBackColor = false;
			this.changeBtn.Click += new System.EventHandler(this.changeBtn_Click);
			// 
			// register
			// 
			this.register.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
			this.register.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.register.ForeColor = System.Drawing.Color.Red;
			this.register.Location = new System.Drawing.Point(324, 321);
			this.register.Name = "register";
			this.register.Size = new System.Drawing.Size(104, 39);
			this.register.TabIndex = 88;
			this.register.Text = "Exit";
			this.register.UseVisualStyleBackColor = false;
			this.register.Click += new System.EventHandler(this.register_Click);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label2.Location = new System.Drawing.Point(66, 202);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(150, 19);
			this.label2.TabIndex = 87;
			this.label2.Text = "confirm password";
			// 
			// confirmPasswordTxtB
			// 
			this.confirmPasswordTxtB.Location = new System.Drawing.Point(222, 203);
			this.confirmPasswordTxtB.Name = "confirmPasswordTxtB";
			this.confirmPasswordTxtB.Size = new System.Drawing.Size(254, 20);
			this.confirmPasswordTxtB.TabIndex = 86;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label1.Location = new System.Drawing.Point(88, 152);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(125, 19);
			this.label1.TabIndex = 85;
			this.label1.Text = "New password";
			// 
			// newPasswordTxtB
			// 
			this.newPasswordTxtB.Location = new System.Drawing.Point(222, 153);
			this.newPasswordTxtB.Name = "newPasswordTxtB";
			this.newPasswordTxtB.Size = new System.Drawing.Size(254, 20);
			this.newPasswordTxtB.TabIndex = 84;
			// 
			// passwordMandatoryLbl
			// 
			this.passwordMandatoryLbl.AutoSize = true;
			this.passwordMandatoryLbl.Font = new System.Drawing.Font("Maiandra GD", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.passwordMandatoryLbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.passwordMandatoryLbl.Location = new System.Drawing.Point(219, 126);
			this.passwordMandatoryLbl.Name = "passwordMandatoryLbl";
			this.passwordMandatoryLbl.Size = new System.Drawing.Size(257, 15);
			this.passwordMandatoryLbl.TabIndex = 107;
			this.passwordMandatoryLbl.Text = "Enter current password MANDATORY!!!";
			this.passwordMandatoryLbl.Visible = false;
			// 
			// newPasswordFieldEmptyErrorLbl
			// 
			this.newPasswordFieldEmptyErrorLbl.AutoSize = true;
			this.newPasswordFieldEmptyErrorLbl.Font = new System.Drawing.Font("Maiandra GD", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.newPasswordFieldEmptyErrorLbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.newPasswordFieldEmptyErrorLbl.Location = new System.Drawing.Point(220, 182);
			this.newPasswordFieldEmptyErrorLbl.Name = "newPasswordFieldEmptyErrorLbl";
			this.newPasswordFieldEmptyErrorLbl.Size = new System.Drawing.Size(274, 15);
			this.newPasswordFieldEmptyErrorLbl.TabIndex = 108;
			this.newPasswordFieldEmptyErrorLbl.Text = "New password entries can not be empty!!!";
			this.newPasswordFieldEmptyErrorLbl.Visible = false;
			// 
			// Change_user_name_and_password
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.newPasswordFieldEmptyErrorLbl);
			this.Controls.Add(this.passwordMandatoryLbl);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.confirmationPasswordTxtB);
			this.Controls.Add(this.changeBtn);
			this.Controls.Add(this.register);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.confirmPasswordTxtB);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.newPasswordTxtB);
			this.Name = "Change_user_name_and_password";
			this.Text = "Change_user_name_and_password";
			this.Load += new System.EventHandler(this.Change_user_name_and_password_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox confirmationPasswordTxtB;
		private System.Windows.Forms.Button changeBtn;
		private System.Windows.Forms.Button register;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox confirmPasswordTxtB;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox newPasswordTxtB;
		private System.Windows.Forms.Label passwordMandatoryLbl;
		private System.Windows.Forms.Label newPasswordFieldEmptyErrorLbl;
	}
}