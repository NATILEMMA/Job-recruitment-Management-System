﻿
namespace CSharpProject.settingsSubForm
{
	partial class Delete_account
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.passwordTxtB = new System.Windows.Forms.Label();
			this.confirmationPasswordTxtB = new System.Windows.Forms.TextBox();
			this.updateBtn = new System.Windows.Forms.Button();
			this.register = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// passwordTxtB
			// 
			this.passwordTxtB.AutoSize = true;
			this.passwordTxtB.BackColor = System.Drawing.Color.Transparent;
			this.passwordTxtB.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.passwordTxtB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.passwordTxtB.Location = new System.Drawing.Point(128, 112);
			this.passwordTxtB.Name = "passwordTxtB";
			this.passwordTxtB.Size = new System.Drawing.Size(82, 19);
			this.passwordTxtB.TabIndex = 93;
			this.passwordTxtB.Text = "password";
			// 
			// confirmationPasswordTxtB
			// 
			this.confirmationPasswordTxtB.Location = new System.Drawing.Point(54, 149);
			this.confirmationPasswordTxtB.Name = "confirmationPasswordTxtB";
			this.confirmationPasswordTxtB.Size = new System.Drawing.Size(254, 20);
			this.confirmationPasswordTxtB.TabIndex = 92;
			this.confirmationPasswordTxtB.UseSystemPasswordChar = true;
			// 
			// updateBtn
			// 
			this.updateBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.updateBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.updateBtn.ForeColor = System.Drawing.Color.DarkMagenta;
			this.updateBtn.Location = new System.Drawing.Point(457, 95);
			this.updateBtn.Name = "updateBtn";
			this.updateBtn.Size = new System.Drawing.Size(192, 39);
			this.updateBtn.TabIndex = 95;
			this.updateBtn.Text = "Cancel Account delete";
			this.updateBtn.UseVisualStyleBackColor = false;
			this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
			// 
			// register
			// 
			this.register.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
			this.register.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.register.ForeColor = System.Drawing.Color.Black;
			this.register.Location = new System.Drawing.Point(457, 183);
			this.register.Name = "register";
			this.register.Size = new System.Drawing.Size(196, 39);
			this.register.TabIndex = 94;
			this.register.Text = "Delete Account";
			this.register.UseVisualStyleBackColor = false;
			this.register.Click += new System.EventHandler(this.register_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label1.Location = new System.Drawing.Point(35, 336);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(698, 19);
			this.label1.TabIndex = 96;
			this.label1.Text = "if you delete the account the information associated with this account will be de" +
    "leted!";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.BackColor = System.Drawing.Color.Yellow;
			this.label2.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label2.Location = new System.Drawing.Point(300, 304);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(96, 19);
			this.label2.TabIndex = 97;
			this.label2.Text = "Caution !!!";
			// 
			// Delete_account
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(777, 383);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.updateBtn);
			this.Controls.Add(this.register);
			this.Controls.Add(this.passwordTxtB);
			this.Controls.Add(this.confirmationPasswordTxtB);
			this.Name = "Delete_account";
			this.Text = "Delete_account";
			this.Load += new System.EventHandler(this.Delete_account_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label passwordTxtB;
		private System.Windows.Forms.TextBox confirmationPasswordTxtB;
		private System.Windows.Forms.Button updateBtn;
		private System.Windows.Forms.Button register;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
	}
}