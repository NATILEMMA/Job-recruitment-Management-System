﻿
namespace CSharpProject.settingsSubForm
{
	partial class Change_personal_information
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel3 = new System.Windows.Forms.Panel();
			this.updateBtn = new System.Windows.Forms.Button();
			this.register = new System.Windows.Forms.Button();
			this.panel2 = new System.Windows.Forms.Panel();
			this.label14 = new System.Windows.Forms.Label();
			this.contactTxtB = new System.Windows.Forms.TextBox();
			this.label13 = new System.Windows.Forms.Label();
			this.addressTxtB = new System.Windows.Forms.TextBox();
			this.cityTxtB = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.countryTxtB = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.label12 = new System.Windows.Forms.Label();
			this.userNameTxtB = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.firstNameTxtB = new System.Windows.Forms.TextBox();
			this.lastNameTxtB = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.femaleRb = new System.Windows.Forms.RadioButton();
			this.fatherNameTxtB = new System.Windows.Forms.TextBox();
			this.maleRb = new System.Windows.Forms.RadioButton();
			this.panel3.SuspendLayout();
			this.panel2.SuspendLayout();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.White;
			this.panel3.Controls.Add(this.updateBtn);
			this.panel3.Controls.Add(this.register);
			this.panel3.Location = new System.Drawing.Point(2, 435);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(960, 55);
			this.panel3.TabIndex = 85;
			// 
			// updateBtn
			// 
			this.updateBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.updateBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.updateBtn.ForeColor = System.Drawing.Color.DarkMagenta;
			this.updateBtn.Location = new System.Drawing.Point(234, 13);
			this.updateBtn.Name = "updateBtn";
			this.updateBtn.Size = new System.Drawing.Size(104, 39);
			this.updateBtn.TabIndex = 79;
			this.updateBtn.Text = "Update";
			this.updateBtn.UseVisualStyleBackColor = false;
			this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
			// 
			// register
			// 
			this.register.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
			this.register.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.register.ForeColor = System.Drawing.Color.Red;
			this.register.Location = new System.Drawing.Point(558, 13);
			this.register.Name = "register";
			this.register.Size = new System.Drawing.Size(104, 39);
			this.register.TabIndex = 78;
			this.register.Text = "Exit";
			this.register.UseVisualStyleBackColor = false;
			this.register.Click += new System.EventHandler(this.register_Click);
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.panel2.Controls.Add(this.label14);
			this.panel2.Controls.Add(this.contactTxtB);
			this.panel2.Controls.Add(this.label13);
			this.panel2.Controls.Add(this.addressTxtB);
			this.panel2.Controls.Add(this.cityTxtB);
			this.panel2.Controls.Add(this.label3);
			this.panel2.Controls.Add(this.countryTxtB);
			this.panel2.Controls.Add(this.label4);
			this.panel2.Location = new System.Drawing.Point(460, 3);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(502, 426);
			this.panel2.TabIndex = 84;
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.BackColor = System.Drawing.Color.Transparent;
			this.label14.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label14.Location = new System.Drawing.Point(9, 62);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(71, 19);
			this.label14.TabIndex = 67;
			this.label14.Text = "Contact";
			// 
			// contactTxtB
			// 
			this.contactTxtB.Location = new System.Drawing.Point(113, 61);
			this.contactTxtB.Name = "contactTxtB";
			this.contactTxtB.Size = new System.Drawing.Size(254, 20);
			this.contactTxtB.TabIndex = 62;
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.BackColor = System.Drawing.Color.Transparent;
			this.label13.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label13.Location = new System.Drawing.Point(9, 185);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(69, 19);
			this.label13.TabIndex = 66;
			this.label13.Text = "Address";
			// 
			// addressTxtB
			// 
			this.addressTxtB.Location = new System.Drawing.Point(113, 187);
			this.addressTxtB.Multiline = true;
			this.addressTxtB.Name = "addressTxtB";
			this.addressTxtB.Size = new System.Drawing.Size(254, 55);
			this.addressTxtB.TabIndex = 68;
			// 
			// cityTxtB
			// 
			this.cityTxtB.Location = new System.Drawing.Point(113, 101);
			this.cityTxtB.Name = "cityTxtB";
			this.cityTxtB.Size = new System.Drawing.Size(254, 20);
			this.cityTxtB.TabIndex = 72;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label3.Location = new System.Drawing.Point(9, 143);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(70, 19);
			this.label3.TabIndex = 69;
			this.label3.Text = "country";
			// 
			// countryTxtB
			// 
			this.countryTxtB.Location = new System.Drawing.Point(113, 144);
			this.countryTxtB.Name = "countryTxtB";
			this.countryTxtB.Size = new System.Drawing.Size(254, 20);
			this.countryTxtB.TabIndex = 71;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.BackColor = System.Drawing.Color.Transparent;
			this.label4.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label4.Location = new System.Drawing.Point(19, 102);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(37, 19);
			this.label4.TabIndex = 70;
			this.label4.Text = "city";
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.panel1.Controls.Add(this.label12);
			this.panel1.Controls.Add(this.userNameTxtB);
			this.panel1.Controls.Add(this.label5);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.firstNameTxtB);
			this.panel1.Controls.Add(this.lastNameTxtB);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.label6);
			this.panel1.Controls.Add(this.femaleRb);
			this.panel1.Controls.Add(this.fatherNameTxtB);
			this.panel1.Controls.Add(this.maleRb);
			this.panel1.Location = new System.Drawing.Point(2, 3);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(452, 426);
			this.panel1.TabIndex = 83;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.BackColor = System.Drawing.Color.Transparent;
			this.label12.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label12.Location = new System.Drawing.Point(8, 183);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(97, 19);
			this.label12.TabIndex = 79;
			this.label12.Text = "User Name";
			// 
			// userNameTxtB
			// 
			this.userNameTxtB.Location = new System.Drawing.Point(142, 184);
			this.userNameTxtB.Name = "userNameTxtB";
			this.userNameTxtB.Size = new System.Drawing.Size(254, 20);
			this.userNameTxtB.TabIndex = 78;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.BackColor = System.Drawing.Color.Transparent;
			this.label5.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label5.Location = new System.Drawing.Point(3, 102);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(112, 19);
			this.label5.TabIndex = 74;
			this.label5.Text = "Father Name";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label1.Location = new System.Drawing.Point(10, 62);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(95, 19);
			this.label1.TabIndex = 59;
			this.label1.Text = "First Name";
			// 
			// firstNameTxtB
			// 
			this.firstNameTxtB.Location = new System.Drawing.Point(142, 62);
			this.firstNameTxtB.Name = "firstNameTxtB";
			this.firstNameTxtB.Size = new System.Drawing.Size(254, 20);
			this.firstNameTxtB.TabIndex = 60;
			// 
			// lastNameTxtB
			// 
			this.lastNameTxtB.Location = new System.Drawing.Point(142, 142);
			this.lastNameTxtB.Name = "lastNameTxtB";
			this.lastNameTxtB.Size = new System.Drawing.Size(254, 20);
			this.lastNameTxtB.TabIndex = 63;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label2.Location = new System.Drawing.Point(21, 223);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(67, 19);
			this.label2.TabIndex = 77;
			this.label2.Text = "Gender";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.BackColor = System.Drawing.Color.Transparent;
			this.label6.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label6.Location = new System.Drawing.Point(10, 143);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(91, 19);
			this.label6.TabIndex = 64;
			this.label6.Text = "Last Name";
			// 
			// femaleRb
			// 
			this.femaleRb.AutoSize = true;
			this.femaleRb.Location = new System.Drawing.Point(257, 225);
			this.femaleRb.Name = "femaleRb";
			this.femaleRb.Size = new System.Drawing.Size(59, 17);
			this.femaleRb.TabIndex = 76;
			this.femaleRb.TabStop = true;
			this.femaleRb.Text = "Female";
			this.femaleRb.UseVisualStyleBackColor = true;
			// 
			// fatherNameTxtB
			// 
			this.fatherNameTxtB.Location = new System.Drawing.Point(142, 101);
			this.fatherNameTxtB.Name = "fatherNameTxtB";
			this.fatherNameTxtB.Size = new System.Drawing.Size(254, 20);
			this.fatherNameTxtB.TabIndex = 73;
			// 
			// maleRb
			// 
			this.maleRb.AutoSize = true;
			this.maleRb.Location = new System.Drawing.Point(179, 225);
			this.maleRb.Name = "maleRb";
			this.maleRb.Size = new System.Drawing.Size(48, 17);
			this.maleRb.TabIndex = 75;
			this.maleRb.TabStop = true;
			this.maleRb.Text = "Male";
			this.maleRb.UseVisualStyleBackColor = true;
			// 
			// Change_personal_information
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(958, 489);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Name = "Change_personal_information";
			this.Text = "Change_personal_information";
			this.Load += new System.EventHandler(this.Change_personal_information_Load);
			this.panel3.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Button updateBtn;
		private System.Windows.Forms.Button register;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.TextBox contactTxtB;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.TextBox addressTxtB;
		private System.Windows.Forms.TextBox cityTxtB;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox countryTxtB;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.TextBox userNameTxtB;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox firstNameTxtB;
		private System.Windows.Forms.TextBox lastNameTxtB;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.RadioButton femaleRb;
		private System.Windows.Forms.TextBox fatherNameTxtB;
		private System.Windows.Forms.RadioButton maleRb;
	}
}