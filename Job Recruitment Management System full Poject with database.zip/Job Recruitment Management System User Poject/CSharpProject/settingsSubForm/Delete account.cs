﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CSharpProject.settingsSubForm
{
	public partial class Delete_account : Form
	{
		SqlConnection conn;
		SqlCommand cmd;
		SqlDataReader sdr;
		String connString = @"Data Source=ናቲ;Initial Catalog=formloginDB;Integrated Security=True";
		private static int accountId;
		public Delete_account()
		{
			InitializeComponent();
		}
		public static void setAccountId(int accountId)
		{
			Delete_account.accountId = accountId;
		}
		private void panel2_Paint(object sender, PaintEventArgs e)
		{

		}
		private void Delete_account_Load(object sender, EventArgs e)
		{

		}
		private void updateBtn_Click(object sender, EventArgs e)
		{
			this.Close();
		}
		private void register_Click(object sender, EventArgs e)
		{
			conn = new SqlConnection(connString);
			conn.Open();
			cmd = new SqlCommand("select  userName, password from userTb where Id = " + accountId+ "", conn);
			sdr = cmd.ExecuteReader();
			if (sdr.Read())
			{
				if (sdr[1].ToString() == confirmationPasswordTxtB.Text.Trim())
				{
					if (MessageBox.Show("Are you sure you want to delete the account with user name: " + sdr[0].ToString() + " ", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
					{
						conn.Close();
						conn.Open();
						cmd = new SqlCommand("delete from userTb where Id = " + accountId + " ",conn);
						cmd.ExecuteNonQuery();
						MessageBox.Show("Deleted.. successfully of account with Id: " + accountId + "");
						conn.Close();
						this.Hide();
						Login login = new Login();
						login.Show();
					}
					conn.Close();
				}
			}
			else
			{
				MessageBox.Show("invalid attempt to read when there is no data present");
			}
		}
	}
}
