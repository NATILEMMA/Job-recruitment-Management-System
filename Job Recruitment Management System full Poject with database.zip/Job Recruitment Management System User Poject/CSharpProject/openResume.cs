﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpProject
{
	public partial class openResume : Form
	{
		int selectedId;
		string filePath;
		public openResume(int selectedId, String filePath)
		{
			this.selectedId = selectedId;
			this.filePath = filePath;
			InitializeComponent();
		}

		private void openResume_Load(object sender, EventArgs e)
		{
			axAcroPDF1.src = filePath;
		}
	}
}
