﻿
namespace CSharpProject
{
	partial class Login
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
			this.userNameLbl = new System.Windows.Forms.Label();
			this.passwordLbl = new System.Windows.Forms.Label();
			this.loginBtn = new System.Windows.Forms.Button();
			this.userNameTxtF = new System.Windows.Forms.TextBox();
			this.passwordTxtF = new System.Windows.Forms.TextBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.label1 = new System.Windows.Forms.Label();
			this.signUp = new System.Windows.Forms.Button();
			this.exit = new System.Windows.Forms.Button();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.imageList1 = new System.Windows.Forms.ImageList(this.components);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// userNameLbl
			// 
			this.userNameLbl.AutoSize = true;
			this.userNameLbl.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.userNameLbl.Location = new System.Drawing.Point(651, 173);
			this.userNameLbl.Name = "userNameLbl";
			this.userNameLbl.Size = new System.Drawing.Size(87, 19);
			this.userNameLbl.TabIndex = 0;
			this.userNameLbl.Text = "Username";
			this.userNameLbl.Click += new System.EventHandler(this.label1_Click);
			// 
			// passwordLbl
			// 
			this.passwordLbl.AutoSize = true;
			this.passwordLbl.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.passwordLbl.Location = new System.Drawing.Point(656, 249);
			this.passwordLbl.Name = "passwordLbl";
			this.passwordLbl.Size = new System.Drawing.Size(82, 19);
			this.passwordLbl.TabIndex = 1;
			this.passwordLbl.Text = "Password";
			// 
			// loginBtn
			// 
			this.loginBtn.BackColor = System.Drawing.Color.Lavender;
			this.loginBtn.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.loginBtn.ForeColor = System.Drawing.Color.Purple;
			this.loginBtn.Location = new System.Drawing.Point(660, 373);
			this.loginBtn.Name = "loginBtn";
			this.loginBtn.Size = new System.Drawing.Size(203, 29);
			this.loginBtn.TabIndex = 3;
			this.loginBtn.Text = "Login";
			this.loginBtn.UseVisualStyleBackColor = false;
			this.loginBtn.Click += new System.EventHandler(this.loginBtn_Click);
			// 
			// userNameTxtF
			// 
			this.userNameTxtF.Location = new System.Drawing.Point(660, 210);
			this.userNameTxtF.Name = "userNameTxtF";
			this.userNameTxtF.Size = new System.Drawing.Size(203, 20);
			this.userNameTxtF.TabIndex = 4;
			this.userNameTxtF.TextChanged += new System.EventHandler(this.userNameTxtF_TextChanged);
			// 
			// passwordTxtF
			// 
			this.passwordTxtF.Location = new System.Drawing.Point(660, 286);
			this.passwordTxtF.Name = "passwordTxtF";
			this.passwordTxtF.Size = new System.Drawing.Size(203, 20);
			this.passwordTxtF.TabIndex = 5;
			this.passwordTxtF.UseSystemPasswordChar = true;
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(0, 0);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(570, 615);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 7;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
			this.label1.Location = new System.Drawing.Point(685, 97);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(144, 23);
			this.label1.TabIndex = 8;
			this.label1.Text = "Ready to login";
			this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// signUp
			// 
			this.signUp.BackColor = System.Drawing.Color.Thistle;
			this.signUp.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.signUp.ForeColor = System.Drawing.Color.Purple;
			this.signUp.Location = new System.Drawing.Point(727, 428);
			this.signUp.Name = "signUp";
			this.signUp.Size = new System.Drawing.Size(75, 29);
			this.signUp.TabIndex = 9;
			this.signUp.Text = "Sign up";
			this.signUp.UseVisualStyleBackColor = false;
			this.signUp.Click += new System.EventHandler(this.button1_Click);
			// 
			// exit
			// 
			this.exit.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.exit.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.exit.ForeColor = System.Drawing.Color.Red;
			this.exit.Location = new System.Drawing.Point(922, 12);
			this.exit.Name = "exit";
			this.exit.Padding = new System.Windows.Forms.Padding(2);
			this.exit.Size = new System.Drawing.Size(75, 28);
			this.exit.TabIndex = 10;
			this.exit.Text = "Exit";
			this.exit.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			this.exit.UseVisualStyleBackColor = true;
			this.exit.Click += new System.EventHandler(this.exit_Click);
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileName = "openFileDialog1";
			// 
			// imageList1
			// 
			this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
			this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Window;
			this.ClientSize = new System.Drawing.Size(1009, 615);
			this.Controls.Add(this.exit);
			this.Controls.Add(this.signUp);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.passwordTxtF);
			this.Controls.Add(this.userNameTxtF);
			this.Controls.Add(this.loginBtn);
			this.Controls.Add(this.passwordLbl);
			this.Controls.Add(this.userNameLbl);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = " ";
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label userNameLbl;
		private System.Windows.Forms.Label passwordLbl;
		private System.Windows.Forms.Button loginBtn;
		private System.Windows.Forms.TextBox userNameTxtF;
		private System.Windows.Forms.TextBox passwordTxtF;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button signUp;
		private System.Windows.Forms.Button exit;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.ImageList imageList1;
	}
}

