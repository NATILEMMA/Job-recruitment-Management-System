﻿
namespace CSharpProject.Forms
{
	partial class vaccancyForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			this.panel1 = new System.Windows.Forms.Panel();
			this.idRb = new System.Windows.Forms.RadioButton();
			this.jobTitleRb = new System.Windows.Forms.RadioButton();
			this.btnSearch = new System.Windows.Forms.Button();
			this.txtSearch = new System.Windows.Forms.TextBox();
			this.panel3 = new System.Windows.Forms.Panel();
			this.vaccancyDGV = new System.Windows.Forms.DataGridView();
			this.panel2 = new System.Windows.Forms.Panel();
			this.errorLbl = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.button5 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			this.panel3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.vaccancyDGV)).BeginInit();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.White;
			this.panel1.Controls.Add(this.idRb);
			this.panel1.Controls.Add(this.jobTitleRb);
			this.panel1.Controls.Add(this.btnSearch);
			this.panel1.Controls.Add(this.txtSearch);
			this.panel1.Location = new System.Drawing.Point(340, 1);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(443, 108);
			this.panel1.TabIndex = 9;
			// 
			// idRb
			// 
			this.idRb.AutoSize = true;
			this.idRb.Location = new System.Drawing.Point(112, 63);
			this.idRb.Name = "idRb";
			this.idRb.Size = new System.Drawing.Size(34, 17);
			this.idRb.TabIndex = 3;
			this.idRb.TabStop = true;
			this.idRb.Text = "Id";
			this.idRb.UseVisualStyleBackColor = true;
			// 
			// jobTitleRb
			// 
			this.jobTitleRb.AutoSize = true;
			this.jobTitleRb.Location = new System.Drawing.Point(112, 40);
			this.jobTitleRb.Name = "jobTitleRb";
			this.jobTitleRb.Size = new System.Drawing.Size(65, 17);
			this.jobTitleRb.TabIndex = 2;
			this.jobTitleRb.TabStop = true;
			this.jobTitleRb.Text = "Job Title";
			this.jobTitleRb.UseVisualStyleBackColor = true;
			// 
			// btnSearch
			// 
			this.btnSearch.Location = new System.Drawing.Point(240, 13);
			this.btnSearch.Name = "btnSearch";
			this.btnSearch.Size = new System.Drawing.Size(75, 23);
			this.btnSearch.TabIndex = 1;
			this.btnSearch.Text = "Search";
			this.btnSearch.UseVisualStyleBackColor = true;
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			// 
			// txtSearch
			// 
			this.txtSearch.Location = new System.Drawing.Point(64, 14);
			this.txtSearch.Name = "txtSearch";
			this.txtSearch.Size = new System.Drawing.Size(152, 20);
			this.txtSearch.TabIndex = 0;
			this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
			// 
			// panel3
			// 
			this.panel3.AllowDrop = true;
			this.panel3.BackColor = System.Drawing.Color.White;
			this.panel3.Controls.Add(this.vaccancyDGV);
			this.panel3.Location = new System.Drawing.Point(255, 112);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(531, 320);
			this.panel3.TabIndex = 8;
			this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
			// 
			// vaccancyDGV
			// 
			this.vaccancyDGV.AllowUserToAddRows = false;
			this.vaccancyDGV.AllowUserToDeleteRows = false;
			this.vaccancyDGV.AllowUserToResizeColumns = false;
			this.vaccancyDGV.AllowUserToResizeRows = false;
			dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Red;
			this.vaccancyDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
			this.vaccancyDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.vaccancyDGV.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
			this.vaccancyDGV.BackgroundColor = System.Drawing.Color.White;
			this.vaccancyDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SunkenHorizontal;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = System.Drawing.Color.Purple;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Maiandra GD", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Purple;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.vaccancyDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
			this.vaccancyDGV.ColumnHeadersHeight = 40;
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle3.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle3.Padding = new System.Windows.Forms.Padding(3);
			dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Red;
			dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.vaccancyDGV.DefaultCellStyle = dataGridViewCellStyle3;
			this.vaccancyDGV.Dock = System.Windows.Forms.DockStyle.Fill;
			this.vaccancyDGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.vaccancyDGV.Location = new System.Drawing.Point(0, 0);
			this.vaccancyDGV.MultiSelect = false;
			this.vaccancyDGV.Name = "vaccancyDGV";
			this.vaccancyDGV.ReadOnly = true;
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle4.BackColor = System.Drawing.Color.Purple;
			dataGridViewCellStyle4.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
			dataGridViewCellStyle4.Padding = new System.Windows.Forms.Padding(3);
			dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Purple;
			dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.vaccancyDGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
			this.vaccancyDGV.RowHeadersWidth = 50;
			this.vaccancyDGV.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			this.vaccancyDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.vaccancyDGV.Size = new System.Drawing.Size(531, 320);
			this.vaccancyDGV.TabIndex = 1;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.White;
			this.panel2.Controls.Add(this.panel1);
			this.panel2.Controls.Add(this.errorLbl);
			this.panel2.Controls.Add(this.label1);
			this.panel2.Location = new System.Drawing.Point(0, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(786, 110);
			this.panel2.TabIndex = 7;
			this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
			// 
			// errorLbl
			// 
			this.errorLbl.AutoSize = true;
			this.errorLbl.BackColor = System.Drawing.Color.Transparent;
			this.errorLbl.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.errorLbl.ForeColor = System.Drawing.Color.Red;
			this.errorLbl.Location = new System.Drawing.Point(4, 90);
			this.errorLbl.Name = "errorLbl";
			this.errorLbl.Size = new System.Drawing.Size(282, 16);
			this.errorLbl.TabIndex = 7;
			this.errorLbl.Text = "No row was selected! Please select a row.";
			this.errorLbl.Visible = false;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Maiandra GD", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(3, 12);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(218, 22);
			this.label1.TabIndex = 1;
			this.label1.Text = "Vaccancy Management";
			// 
			// button5
			// 
			this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.button5.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button5.ForeColor = System.Drawing.Color.Transparent;
			this.button5.Location = new System.Drawing.Point(24, 278);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(89, 38);
			this.button5.TabIndex = 6;
			this.button5.Text = "View";
			this.button5.UseVisualStyleBackColor = false;
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.Yellow;
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.button1.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button1.ForeColor = System.Drawing.Color.Black;
			this.button1.Location = new System.Drawing.Point(24, 138);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(89, 38);
			this.button1.TabIndex = 2;
			this.button1.Text = "Refresh";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button4
			// 
			this.button4.BackColor = System.Drawing.Color.Lime;
			this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.button4.Font = new System.Drawing.Font("Maiandra GD", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button4.ForeColor = System.Drawing.Color.Black;
			this.button4.Location = new System.Drawing.Point(24, 204);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(89, 38);
			this.button4.TabIndex = 9;
			this.button4.Text = "+ New Applicant";
			this.button4.UseVisualStyleBackColor = false;
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// vaccancyForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.button4);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.button5);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.button1);
			this.Name = "vaccancyForm";
			this.Text = "Vaccancy";
			this.Load += new System.EventHandler(this.vaccancyForm_Load);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.panel3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.vaccancyDGV)).EndInit();
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.RadioButton idRb;
		private System.Windows.Forms.RadioButton jobTitleRb;
		private System.Windows.Forms.Button btnSearch;
		private System.Windows.Forms.TextBox txtSearch;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.DataGridView vaccancyDGV;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label errorLbl;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button4;
	}
}