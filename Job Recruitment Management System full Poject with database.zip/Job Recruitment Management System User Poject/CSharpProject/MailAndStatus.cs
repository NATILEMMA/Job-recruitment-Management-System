﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CSharpProject
{
	public partial class MailAndStatus : Form
	{
		int selectedRowId;
		SqlConnection conn;
		SqlCommand cmd;
		SqlDataReader sdr;
		String connString = "Data Source=ናቲ;Initial Catalog=formloginDB;Integrated Security=True";
		public MailAndStatus(int selectedRowId)
		{
			InitializeComponent();
			this.selectedRowId = selectedRowId;
		}

		private void MailAndStatus_Load(object sender, EventArgs e)
		{
			conn = new SqlConnection(connString);
			conn.Open();
			cmd = new SqlCommand("select status, Mail from applicationsTb where Id = " + selectedRowId + " ",conn);
			sdr = cmd.ExecuteReader();

			if (sdr.Read())
			{
				statusLbl.Text = sdr[0].ToString();
				mailTb.Text = sdr[1].ToString();

			}
			conn.Close();
		}

		private void coverLetterTb_TextChanged(object sender, EventArgs e)
		{

		}

		private void exitBtn_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
