﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CSharpProject.vaccancySubForm
{
	public partial class Information : Form
	{
		SqlConnection conn;
		SqlCommand cmd;
		SqlDataAdapter sda;
		SqlDataReader dreader;
		String connString = @"Data Source=ናቲ;Initial Catalog=formloginDB;Integrated Security=True";
		int selectedId;
		String senderForm;
		public Information(int selectedId, String senderForm)
		{
			InitializeComponent();
			this.selectedId = selectedId;
			this.senderForm = senderForm;
		}

		private void Information_Load(object sender, EventArgs e)
		{
			if (senderForm == "view")
				updateBtn.Visible = false;


			conn = new SqlConnection(connString);
			conn.Open();
			cmd = new SqlCommand("select * from vaccancyTb where Id =" + selectedId + " ", conn);

			try
			{
				dreader = cmd.ExecuteReader();
				if (dreader.Read())
				{

					txtJobTitle.Text = dreader[0].ToString();
					txtCompany.Text = dreader[1].ToString();
					txtJobType.Text = dreader[2].ToString();
					txtDiscription.Text = dreader[3].ToString();
					txtSalary.Text = dreader[4].ToString();
					txtDeadline.Text = dreader[5].ToString();
				}
			}
			catch (Exception)
			{
				MessageBox.Show(" not record");
			}
			finally { conn.Close(); }
		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{

		}

		private void updateBtn_Click(object sender, EventArgs e)
		{

			conn = new SqlConnection(connString);
			conn.Open();
			cmd = new SqlCommand("update vaccancyTb set JobTitle ='"+txtJobTitle.Text+"',Company = '"+txtCompany.Text+"', JobType=' " +txtJobType.Text+ "', Discription =' " + txtDiscription.Text+ "', Salary =' " + txtSalary.Text + "', Deadline =' " + txtDeadline.Text + "' where Id =" + selectedId + " ", conn);
			try
			{
				cmd.ExecuteNonQuery();
				MessageBox.Show("updated...");
			}
			catch (Exception)
			{
				MessageBox.Show(" Not updated!!!! ");
			}
			finally { conn.Close(); }
		}
		private void exitBtn_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}

	}