﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CSharpProject
{
	public partial class MailAndStatus : Form
	{
		SqlConnection conn;
		SqlCommand cmd;
		SqlDataAdapter sda;
		SqlDataReader dreader;
		String connString = @"Data Source=ናቲ;Initial Catalog=formloginDB;Integrated Security=True";
		int selectedId;
		public MailAndStatus(int selectedRowId)
		{
			InitializeComponent();
			selectedId = selectedRowId;
		}

		private void MailAndStatus_Load(object sender, EventArgs e)
		{
			statusCb.SelectedIndex = 0;	
		}

		private void updateBtn_Click(object sender, EventArgs e)
		{
			String changeStatus = statusCb.SelectedItem.ToString();
			conn = new SqlConnection(connString);
			conn.Open();
				cmd = new SqlCommand(@"update  applicationsTb set status = '" + changeStatus + "' , Mail = '"+mailTb.Text+"' where Id = " + selectedId + "  ", conn);
				cmd.ExecuteNonQuery();
				MessageBox.Show("Status updated to " + changeStatus + " for the applicant with Id: " + selectedId + "");
				conn.Close();
			}

		private void exitBtn_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}

