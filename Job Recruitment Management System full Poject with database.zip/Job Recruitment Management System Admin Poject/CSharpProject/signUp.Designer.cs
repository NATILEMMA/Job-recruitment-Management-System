﻿
namespace CSharpProject
{
	partial class signUp
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.firstNameTxtB = new System.Windows.Forms.TextBox();
			this.confirmPasswordTxtB = new System.Windows.Forms.TextBox();
			this.passwordTxtB = new System.Windows.Forms.TextBox();
			this.userNameTxtB = new System.Windows.Forms.TextBox();
			this.contactTxtB = new System.Windows.Forms.TextBox();
			this.LastNameTxtB = new System.Windows.Forms.TextBox();
			this.submitBtn = new System.Windows.Forms.Button();
			this.label6 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.addressTxtB = new System.Windows.Forms.TextBox();
			this.backToLoginBtn = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.label5 = new System.Windows.Forms.Label();
			this.fatherNameTxtB = new System.Windows.Forms.TextBox();
			this.cityTxtB = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.countryTxtB = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.panel3 = new System.Windows.Forms.Panel();
			this.personalInformationErrorLbl = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.isFemaleRb = new System.Windows.Forms.RadioButton();
			this.isMaleRb = new System.Windows.Forms.RadioButton();
			this.panel4 = new System.Windows.Forms.Panel();
			this.locationInformationErrorLbl = new System.Windows.Forms.Label();
			this.contactError = new System.Windows.Forms.Label();
			this.userNamePasswordPanel = new System.Windows.Forms.Panel();
			this.accountInformationErrorLbl = new System.Windows.Forms.Label();
			this.updateBtn = new System.Windows.Forms.Button();
			this.exitBtn = new System.Windows.Forms.Button();
			this.updatePanel = new System.Windows.Forms.Panel();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.panel3.SuspendLayout();
			this.panel4.SuspendLayout();
			this.userNamePasswordPanel.SuspendLayout();
			this.updatePanel.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label1.Location = new System.Drawing.Point(49, 23);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(95, 19);
			this.label1.TabIndex = 0;
			this.label1.Text = "First Name";
			// 
			// firstNameTxtB
			// 
			this.firstNameTxtB.Location = new System.Drawing.Point(181, 23);
			this.firstNameTxtB.Name = "firstNameTxtB";
			this.firstNameTxtB.Size = new System.Drawing.Size(254, 20);
			this.firstNameTxtB.TabIndex = 7;
			this.firstNameTxtB.TextChanged += new System.EventHandler(this.firstNameTxtB_TextChanged);
			// 
			// confirmPasswordTxtB
			// 
			this.confirmPasswordTxtB.Location = new System.Drawing.Point(666, 80);
			this.confirmPasswordTxtB.Name = "confirmPasswordTxtB";
			this.confirmPasswordTxtB.Size = new System.Drawing.Size(254, 20);
			this.confirmPasswordTxtB.TabIndex = 8;
			this.confirmPasswordTxtB.UseSystemPasswordChar = true;
			// 
			// passwordTxtB
			// 
			this.passwordTxtB.Location = new System.Drawing.Point(666, 32);
			this.passwordTxtB.Name = "passwordTxtB";
			this.passwordTxtB.Size = new System.Drawing.Size(254, 20);
			this.passwordTxtB.TabIndex = 9;
			this.passwordTxtB.UseSystemPasswordChar = true;
			// 
			// userNameTxtB
			// 
			this.userNameTxtB.Location = new System.Drawing.Point(31, 62);
			this.userNameTxtB.Name = "userNameTxtB";
			this.userNameTxtB.Size = new System.Drawing.Size(254, 20);
			this.userNameTxtB.TabIndex = 10;
			// 
			// contactTxtB
			// 
			this.contactTxtB.Location = new System.Drawing.Point(181, 22);
			this.contactTxtB.Name = "contactTxtB";
			this.contactTxtB.Size = new System.Drawing.Size(254, 20);
			this.contactTxtB.TabIndex = 12;
			this.contactTxtB.TextChanged += new System.EventHandler(this.contactTxtB_TextChanged);
			// 
			// LastNameTxtB
			// 
			this.LastNameTxtB.Location = new System.Drawing.Point(181, 99);
			this.LastNameTxtB.Name = "LastNameTxtB";
			this.LastNameTxtB.Size = new System.Drawing.Size(254, 20);
			this.LastNameTxtB.TabIndex = 13;
			this.LastNameTxtB.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
			// 
			// submitBtn
			// 
			this.submitBtn.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.submitBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.submitBtn.Location = new System.Drawing.Point(829, 0);
			this.submitBtn.Name = "submitBtn";
			this.submitBtn.Size = new System.Drawing.Size(131, 28);
			this.submitBtn.TabIndex = 16;
			this.submitBtn.Text = "Submit";
			this.submitBtn.UseVisualStyleBackColor = true;
			this.submitBtn.Click += new System.EventHandler(this.submite_Click);
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.BackColor = System.Drawing.Color.Transparent;
			this.label6.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label6.Location = new System.Drawing.Point(49, 100);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(91, 19);
			this.label6.TabIndex = 17;
			this.label6.Text = "Last Name";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.BackColor = System.Drawing.Color.Transparent;
			this.label10.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label10.Location = new System.Drawing.Point(470, 81);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(154, 19);
			this.label10.TabIndex = 19;
			this.label10.Text = "Confirm Password";
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.BackColor = System.Drawing.Color.Transparent;
			this.label11.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label11.Location = new System.Drawing.Point(542, 29);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(82, 19);
			this.label11.TabIndex = 20;
			this.label11.Text = "Password";
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.BackColor = System.Drawing.Color.Transparent;
			this.label12.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label12.Location = new System.Drawing.Point(27, 40);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(97, 19);
			this.label12.TabIndex = 21;
			this.label12.Text = "User Name";
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.BackColor = System.Drawing.Color.Transparent;
			this.label13.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label13.Location = new System.Drawing.Point(70, 77);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(69, 19);
			this.label13.TabIndex = 22;
			this.label13.Text = "Address";
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.BackColor = System.Drawing.Color.Transparent;
			this.label14.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label14.Location = new System.Drawing.Point(71, 23);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(71, 19);
			this.label14.TabIndex = 23;
			this.label14.Text = "Contact";
			// 
			// addressTxtB
			// 
			this.addressTxtB.Location = new System.Drawing.Point(181, 77);
			this.addressTxtB.Multiline = true;
			this.addressTxtB.Name = "addressTxtB";
			this.addressTxtB.Size = new System.Drawing.Size(254, 55);
			this.addressTxtB.TabIndex = 24;
			// 
			// backToLoginBtn
			// 
			this.backToLoginBtn.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.backToLoginBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.backToLoginBtn.Location = new System.Drawing.Point(829, 0);
			this.backToLoginBtn.Name = "backToLoginBtn";
			this.backToLoginBtn.Size = new System.Drawing.Size(131, 30);
			this.backToLoginBtn.TabIndex = 25;
			this.backToLoginBtn.Text = "Back to Login ";
			this.backToLoginBtn.UseVisualStyleBackColor = true;
			this.backToLoginBtn.Click += new System.EventHandler(this.button1_Click);
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.White;
			this.panel1.Controls.Add(this.backToLoginBtn);
			this.panel1.Location = new System.Drawing.Point(1, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1084, 30);
			this.panel1.TabIndex = 26;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.White;
			this.panel2.Controls.Add(this.submitBtn);
			this.panel2.Location = new System.Drawing.Point(1, 533);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(1084, 29);
			this.panel2.TabIndex = 27;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.BackColor = System.Drawing.Color.Transparent;
			this.label5.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label5.Location = new System.Drawing.Point(42, 64);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(112, 19);
			this.label5.TabIndex = 76;
			this.label5.Text = "Father Name";
			// 
			// fatherNameTxtB
			// 
			this.fatherNameTxtB.Location = new System.Drawing.Point(181, 63);
			this.fatherNameTxtB.Name = "fatherNameTxtB";
			this.fatherNameTxtB.Size = new System.Drawing.Size(254, 20);
			this.fatherNameTxtB.TabIndex = 75;
			// 
			// cityTxtB
			// 
			this.cityTxtB.Location = new System.Drawing.Point(178, 145);
			this.cityTxtB.Name = "cityTxtB";
			this.cityTxtB.Size = new System.Drawing.Size(254, 20);
			this.cityTxtB.TabIndex = 84;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label3.Location = new System.Drawing.Point(65, 185);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(70, 19);
			this.label3.TabIndex = 81;
			this.label3.Text = "country";
			// 
			// countryTxtB
			// 
			this.countryTxtB.Location = new System.Drawing.Point(178, 184);
			this.countryTxtB.Name = "countryTxtB";
			this.countryTxtB.Size = new System.Drawing.Size(254, 20);
			this.countryTxtB.TabIndex = 83;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.BackColor = System.Drawing.Color.Transparent;
			this.label4.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label4.Location = new System.Drawing.Point(98, 143);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(37, 19);
			this.label4.TabIndex = 82;
			this.label4.Text = "city";
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.panel3.Controls.Add(this.personalInformationErrorLbl);
			this.panel3.Controls.Add(this.label7);
			this.panel3.Controls.Add(this.label1);
			this.panel3.Controls.Add(this.isFemaleRb);
			this.panel3.Controls.Add(this.firstNameTxtB);
			this.panel3.Controls.Add(this.isMaleRb);
			this.panel3.Controls.Add(this.LastNameTxtB);
			this.panel3.Controls.Add(this.label6);
			this.panel3.Controls.Add(this.fatherNameTxtB);
			this.panel3.Controls.Add(this.label5);
			this.panel3.Location = new System.Drawing.Point(1, 36);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(475, 282);
			this.panel3.TabIndex = 85;
			// 
			// personalInformationErrorLbl
			// 
			this.personalInformationErrorLbl.AutoSize = true;
			this.personalInformationErrorLbl.Font = new System.Drawing.Font("Maiandra GD", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.personalInformationErrorLbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.personalInformationErrorLbl.Location = new System.Drawing.Point(11, 198);
			this.personalInformationErrorLbl.Name = "personalInformationErrorLbl";
			this.personalInformationErrorLbl.Size = new System.Drawing.Size(447, 18);
			this.personalInformationErrorLbl.TabIndex = 109;
			this.personalInformationErrorLbl.Text = "Mandatory fields for Personal information cant be empty!!!";
			this.personalInformationErrorLbl.Visible = false;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.BackColor = System.Drawing.Color.Transparent;
			this.label7.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label7.Location = new System.Drawing.Point(68, 130);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(67, 19);
			this.label7.TabIndex = 88;
			this.label7.Text = "Gender";
			// 
			// isFemaleRb
			// 
			this.isFemaleRb.AutoSize = true;
			this.isFemaleRb.Location = new System.Drawing.Point(280, 132);
			this.isFemaleRb.Name = "isFemaleRb";
			this.isFemaleRb.Size = new System.Drawing.Size(59, 17);
			this.isFemaleRb.TabIndex = 87;
			this.isFemaleRb.TabStop = true;
			this.isFemaleRb.Text = "Female";
			this.isFemaleRb.UseVisualStyleBackColor = true;
			// 
			// isMaleRb
			// 
			this.isMaleRb.AutoSize = true;
			this.isMaleRb.Location = new System.Drawing.Point(181, 132);
			this.isMaleRb.Name = "isMaleRb";
			this.isMaleRb.Size = new System.Drawing.Size(48, 17);
			this.isMaleRb.TabIndex = 86;
			this.isMaleRb.TabStop = true;
			this.isMaleRb.Text = "Male";
			this.isMaleRb.UseVisualStyleBackColor = true;
			// 
			// panel4
			// 
			this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.panel4.Controls.Add(this.locationInformationErrorLbl);
			this.panel4.Controls.Add(this.contactError);
			this.panel4.Controls.Add(this.contactTxtB);
			this.panel4.Controls.Add(this.cityTxtB);
			this.panel4.Controls.Add(this.label13);
			this.panel4.Controls.Add(this.label14);
			this.panel4.Controls.Add(this.label3);
			this.panel4.Controls.Add(this.addressTxtB);
			this.panel4.Controls.Add(this.countryTxtB);
			this.panel4.Controls.Add(this.label4);
			this.panel4.Location = new System.Drawing.Point(489, 36);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(596, 282);
			this.panel4.TabIndex = 86;
			// 
			// locationInformationErrorLbl
			// 
			this.locationInformationErrorLbl.AutoSize = true;
			this.locationInformationErrorLbl.Font = new System.Drawing.Font("Maiandra GD", 11.25F, System.Drawing.FontStyle.Bold);
			this.locationInformationErrorLbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.locationInformationErrorLbl.Location = new System.Drawing.Point(28, 239);
			this.locationInformationErrorLbl.Name = "locationInformationErrorLbl";
			this.locationInformationErrorLbl.Size = new System.Drawing.Size(410, 18);
			this.locationInformationErrorLbl.TabIndex = 110;
			this.locationInformationErrorLbl.Text = "Fill the location information or put NUll if not known";
			this.locationInformationErrorLbl.Visible = false;
			// 
			// contactError
			// 
			this.contactError.AutoSize = true;
			this.contactError.Font = new System.Drawing.Font("Maiandra GD", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.contactError.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.contactError.Location = new System.Drawing.Point(178, 45);
			this.contactError.Name = "contactError";
			this.contactError.Size = new System.Drawing.Size(185, 15);
			this.contactError.TabIndex = 107;
			this.contactError.Text = "enter valid phone number!!!";
			this.contactError.Visible = false;
			// 
			// userNamePasswordPanel
			// 
			this.userNamePasswordPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.userNamePasswordPanel.Controls.Add(this.accountInformationErrorLbl);
			this.userNamePasswordPanel.Controls.Add(this.userNameTxtB);
			this.userNamePasswordPanel.Controls.Add(this.label12);
			this.userNamePasswordPanel.Controls.Add(this.confirmPasswordTxtB);
			this.userNamePasswordPanel.Controls.Add(this.passwordTxtB);
			this.userNamePasswordPanel.Controls.Add(this.label10);
			this.userNamePasswordPanel.Controls.Add(this.label11);
			this.userNamePasswordPanel.Location = new System.Drawing.Point(1, 337);
			this.userNamePasswordPanel.Name = "userNamePasswordPanel";
			this.userNamePasswordPanel.Size = new System.Drawing.Size(1081, 146);
			this.userNamePasswordPanel.TabIndex = 87;
			// 
			// accountInformationErrorLbl
			// 
			this.accountInformationErrorLbl.AutoSize = true;
			this.accountInformationErrorLbl.Font = new System.Drawing.Font("Maiandra GD", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.accountInformationErrorLbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.accountInformationErrorLbl.Location = new System.Drawing.Point(317, 62);
			this.accountInformationErrorLbl.Name = "accountInformationErrorLbl";
			this.accountInformationErrorLbl.Size = new System.Drawing.Size(325, 15);
			this.accountInformationErrorLbl.TabIndex = 108;
			this.accountInformationErrorLbl.Text = "Mandatory fields for the account can\'t be empty!!!";
			this.accountInformationErrorLbl.Visible = false;
			// 
			// updateBtn
			// 
			this.updateBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.updateBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.updateBtn.ForeColor = System.Drawing.Color.DarkMagenta;
			this.updateBtn.Location = new System.Drawing.Point(50, 0);
			this.updateBtn.Name = "updateBtn";
			this.updateBtn.Size = new System.Drawing.Size(104, 39);
			this.updateBtn.TabIndex = 88;
			this.updateBtn.Text = "Update";
			this.updateBtn.UseVisualStyleBackColor = false;
			this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
			// 
			// exitBtn
			// 
			this.exitBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
			this.exitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.exitBtn.ForeColor = System.Drawing.Color.Red;
			this.exitBtn.Location = new System.Drawing.Point(325, 0);
			this.exitBtn.Name = "exitBtn";
			this.exitBtn.Size = new System.Drawing.Size(104, 39);
			this.exitBtn.TabIndex = 89;
			this.exitBtn.Text = "Exit";
			this.exitBtn.UseVisualStyleBackColor = false;
			this.exitBtn.Click += new System.EventHandler(this.register_Click);
			// 
			// updatePanel
			// 
			this.updatePanel.Controls.Add(this.exitBtn);
			this.updatePanel.Controls.Add(this.updateBtn);
			this.updatePanel.Location = new System.Drawing.Point(251, 489);
			this.updatePanel.Name = "updatePanel";
			this.updatePanel.Size = new System.Drawing.Size(506, 38);
			this.updatePanel.TabIndex = 90;
			// 
			// signUp
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(993, 576);
			this.Controls.Add(this.updatePanel);
			this.Controls.Add(this.userNamePasswordPanel);
			this.Controls.Add(this.panel4);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.ForeColor = System.Drawing.Color.MediumPurple;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Name = "signUp";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "signUp";
			this.Load += new System.EventHandler(this.signUp_Load);
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.panel3.PerformLayout();
			this.panel4.ResumeLayout(false);
			this.panel4.PerformLayout();
			this.userNamePasswordPanel.ResumeLayout(false);
			this.userNamePasswordPanel.PerformLayout();
			this.updatePanel.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox firstNameTxtB;
		private System.Windows.Forms.TextBox confirmPasswordTxtB;
		private System.Windows.Forms.TextBox passwordTxtB;
		private System.Windows.Forms.TextBox userNameTxtB;
		private System.Windows.Forms.TextBox contactTxtB;
		private System.Windows.Forms.TextBox LastNameTxtB;
		private System.Windows.Forms.Button submitBtn;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.TextBox addressTxtB;
		private System.Windows.Forms.Button backToLoginBtn;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox fatherNameTxtB;
		private System.Windows.Forms.TextBox cityTxtB;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox countryTxtB;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.RadioButton isFemaleRb;
		private System.Windows.Forms.RadioButton isMaleRb;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Panel userNamePasswordPanel;
		private System.Windows.Forms.Button updateBtn;
		private System.Windows.Forms.Button exitBtn;
		private System.Windows.Forms.Panel updatePanel;
		private System.Windows.Forms.Label contactError;
		private System.Windows.Forms.Label personalInformationErrorLbl;
		private System.Windows.Forms.Label locationInformationErrorLbl;
		private System.Windows.Forms.Label accountInformationErrorLbl;
	}
}