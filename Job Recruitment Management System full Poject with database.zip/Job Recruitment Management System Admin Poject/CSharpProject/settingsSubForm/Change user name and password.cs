﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace CSharpProject.settingsSubForm
{
	public partial class Change_user_name_and_password : Form
	{
		SqlConnection conn;
		SqlCommand cmd;
		SqlDataReader sdr;
		String connString = @"Data Source=ናቲ;Initial Catalog=formloginDB;Integrated Security=True";
		private static int accountId;
		public Change_user_name_and_password()
		{
			InitializeComponent();
		}
		public static void setAccountId(int accountId)
		{
			Change_user_name_and_password.accountId = accountId;
		}
		private void errorInvisibler()
		{
			passwordMandatoryLbl.Visible = false;
			newPasswordFieldEmptyErrorLbl.Visible = false;
		}

		private void changeBtn_Click(object sender, EventArgs e)
		{
			errorInvisibler();
			
			conn = new SqlConnection(connString);
			conn.Open();
			cmd = new SqlCommand("select  userName, password from administratorTb where Id = " +accountId+ "", conn);
			sdr = cmd.ExecuteReader();

			if (confirmationPasswordTxtB.Text == "")
			{
				passwordMandatoryLbl.Visible = true;
			}
			if(newPasswordTxtB.Text == "" || confirmPasswordTxtB.Text == "")
			{
				newPasswordFieldEmptyErrorLbl.Visible = true;
			}
			else if(confirmPasswordTxtB.Text != newPasswordTxtB.Text)
			{
				MessageBox.Show("New password and confirm password don't match!!!");
			}
			else
			{
				if (sdr.Read() && confirmationPasswordTxtB.Text == sdr[1].ToString())
				{
					conn = new SqlConnection(connString);
					conn.Open();
					cmd = new SqlCommand("select  userName, password from administratorTb where Id = " + accountId + "", conn);
					sdr = cmd.ExecuteReader();
					if (sdr.Read())
					{
						if (MessageBox.Show("Are you sure you want to change the account password ", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
						{

							conn.Close();
							conn.Open();
							cmd = new SqlCommand("update administratorTb set password = '"+confirmPasswordTxtB.Text.Trim()+"' where Id = "+accountId +" ", conn);
							cmd.ExecuteNonQuery();
							MessageBox.Show("Password changed ... successfully!!!");
							conn.Close();
						}
						conn.Close();
					}
				}
				else
				{
					MessageBox.Show(" The password entered doesn't match the account password!!!");
				}
			}
		}
		private void register_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
