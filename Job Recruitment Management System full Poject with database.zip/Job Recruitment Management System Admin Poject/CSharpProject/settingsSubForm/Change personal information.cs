﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CSharpProject.settingsSubForm
{
	public partial class Change_personal_information : Form
	{

		SqlConnection conn;
		SqlCommand cmd;
		SqlDataAdapter sda;
		SqlDataReader dreader;
		String connString = @"Data Source=ናቲ;Initial Catalog=formloginDB;Integrated Security=True";
		int selectedId;
		String senderForm;
		String Gender;
		public Change_personal_information()
		{
			InitializeComponent();
		}

		private void Change_personal_information_Load(object sender, EventArgs e)
		{

			conn = new SqlConnection(connString);
			conn.Open();
			cmd = new SqlCommand("select* from administratorTb where Id =" + selectedId + " ", conn);

			try
			{
				dreader = cmd.ExecuteReader();
				if (dreader.Read())
				{


					userNameTxtB.Text = dreader[0].ToString().Trim();
					firstNameTxtB.Text = dreader[2].ToString().Trim();
					fatherNameTxtB.Text = dreader[3].ToString().Trim();
					lastNameTxtB.Text = dreader[4].ToString().Trim();
					Gender = dreader[10].ToString().Trim();
					contactTxtB.Text = dreader[5].ToString().Trim();
					addressTxtB.Text = dreader[8].ToString().Trim();
					cityTxtB.Text = dreader[6].ToString().Trim();
					countryTxtB.Text = dreader[7].ToString().Trim();


					if (Gender == "Male")
						maleRb.Checked = true;
					else if (Gender == "Female")
						femaleRb.Checked = true;
				}
			}
			catch (Exception)
			{
				MessageBox.Show(" not record");
			}
			finally { conn.Close(); }
		}

		private void updateBtn_Click(object sender, EventArgs e)
		{

			if (maleRb.Checked == true)
				Gender = "Male";
			else if (femaleRb.Checked == true)
				Gender = "Female";
			conn = new SqlConnection(connString);
			conn.Open();
			cmd = new SqlCommand("update administratorTb  set userName = '" + userNameTxtB.Text.Trim() + "', firstName = '" + firstNameTxtB.Text.Trim() + "', fatherName = '" + fatherNameTxtB.Text.Trim() + "', lastName= '" + lastNameTxtB.Text.Trim() + "', gender= '" + Gender.Trim() + "', contact = " + int.Parse(contactTxtB.Text) + " ,city = '" + cityTxtB.Text.Trim() + "', country  = '" + countryTxtB.Text.Trim() + "' , address = '" + addressTxtB.Text.Trim() + "' where Id =" + selectedId + " ", conn);

			cmd.ExecuteNonQuery();
			MessageBox.Show("Updated...");
		}

		private void register_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
