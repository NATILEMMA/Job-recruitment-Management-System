﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CSharpProject
{
   
	public partial class signUp : Form
	{
		String gender  = "Male";
		int AccountId;
		string senderForm = "loginForm";
		string connString = @"Data Source=ናቲ;Initial Catalog=formloginDB;Integrated Security=True";
		public signUp()
		{
			InitializeComponent();
		}
		public signUp(int accountId)
		{
			senderForm = "updateProfileForm";
			InitializeComponent();
			AccountId = accountId;
		}

		private void signUp_Load(object sender, EventArgs e)
		{
			userNameTxtB.Text = passwordTxtB.Text = firstNameTxtB.Text = fatherNameTxtB.Text = LastNameTxtB.Text = addressTxtB.Text = contactTxtB.Text = countryTxtB.Text = cityTxtB.Text = confirmPasswordTxtB.Text = "";
			isMaleRb.Checked = true;
			if (senderForm == "updateProfileForm")
			{
				
				userNamePasswordPanel.Visible = false;
				backToLoginBtn.Visible = false;
				submitBtn.Visible = false;

				using (SqlConnection sqc = new SqlConnection(connString))
				{

					sqc.Open();

					SqlCommand cmd = new SqlCommand(" select * from administratorTb where Id = "+AccountId+"", sqc);
					SqlDataReader sdr = cmd.ExecuteReader();

					if (sdr.Read())
					{
						firstNameTxtB.Text = sdr[0].ToString();
					    fatherNameTxtB.Text = sdr[1].ToString();
						LastNameTxtB.Text = sdr[2].ToString();
						gender = sdr[3].ToString();
						contactTxtB.Text = sdr[4].ToString();
						addressTxtB.Text = sdr[5].ToString();
						cityTxtB.Text = sdr[6].ToString();
						countryTxtB.Text = sdr[7].ToString();
					}
					if (gender == "Male")
						isMaleRb.Checked = true;
					if (gender == "Female")
						isFemaleRb.Checked = true;
				}
				}
			else if (senderForm == "loginForm")
			{
				updatePanel.Visible = false;
			}

		}

		private void label6_Click(object sender, EventArgs e)
		{

		}

		private void textBox5_TextChanged(object sender, EventArgs e)
		{

		}

		private void label4_Click(object sender, EventArgs e)
		{

		}

		private void textBox7_TextChanged(object sender, EventArgs e)
		{

		}

		private bool inputValidator() {
			if (senderForm == "loginForm") {
				if (userNameTxtB.Text == "" || passwordTxtB.Text == "" || confirmPasswordTxtB.Text == "")
				{
					accountInformationErrorLbl.Visible = true;
					return false;
				}
			}
			 if (firstNameTxtB.Text == "" || LastNameTxtB.Text == "" || LastNameTxtB.Text == "")
			{
				personalInformationErrorLbl.Visible = true;
				return false;
			}
			 if (addressTxtB.Text == "" || cityTxtB.Text == "" || countryTxtB.Text == "")
			{
				locationInformationErrorLbl.Visible = true;
				return false;
			}
			
			if (contactTxtB.Text == "") {
				contactError.Visible = true;
				return false;
			}
			Int32 SampleInteger;
			if (!(int.TryParse(contactTxtB.Text,out SampleInteger)) )
			{
				contactError.Visible = true;
				return false;
			}
			else if (passwordTxtB.Text != confirmPasswordTxtB.Text)
			{
				MessageBox.Show("The password and the confirm password  field don't match!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return false;
			}
			else
			{
				return true;
			}
		}

		private void errorInvisibler()
		{
			accountInformationErrorLbl.Visible = false;
			personalInformationErrorLbl.Visible = false;
			locationInformationErrorLbl.Visible = false;
			contactError.Visible = false;
		}
		private void submite_Click(object sender, EventArgs e)
		{
			errorInvisibler();

			if (isFemaleRb.Checked)
				gender = "Female";
			if (inputValidator() == true)
			{
				using (SqlConnection sqc = new SqlConnection(connString))
				{

					sqc.Open();

					SqlCommand cmd = new SqlCommand("spInsertAdmin", sqc);
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.Parameters.AddWithValue("@firstName", firstNameTxtB.Text.Trim());
					cmd.Parameters.AddWithValue("@fatherName", fatherNameTxtB.Text.Trim());
					cmd.Parameters.AddWithValue("@lastName", LastNameTxtB.Text.Trim());
					cmd.Parameters.AddWithValue("@gender", gender);
					cmd.Parameters.AddWithValue("@contact", int.Parse(contactTxtB.Text.Trim()));
					cmd.Parameters.AddWithValue("@address", addressTxtB.Text.Trim());
					cmd.Parameters.AddWithValue("@city", cityTxtB.Text.Trim());
					cmd.Parameters.AddWithValue("@country", countryTxtB.Text.Trim());
					cmd.Parameters.AddWithValue("@userName", userNameTxtB.Text.Trim());
					cmd.Parameters.AddWithValue("@password", passwordTxtB.Text.Trim());
					cmd.ExecuteNonQuery();

					sqc.Close();
					MessageBox.Show("Registration as an Administrator was successfull !!! ", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

					userNameTxtB.Text = passwordTxtB.Text = firstNameTxtB.Text = fatherNameTxtB.Text = LastNameTxtB.Text = addressTxtB.Text = contactTxtB.Text = cityTxtB.Text = countryTxtB.Text = confirmPasswordTxtB.Text = "";
				}
			}

		}

		private void button1_Click(object sender, EventArgs e)
		{

			this.Hide();
			Login loginForm = new Login();
			loginForm.Show();
		}

		private void firstNameTxtB_TextChanged(object sender, EventArgs e)
		{

		}

		private void register_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void updateBtn_Click(object sender, EventArgs e)
		{
			errorInvisibler();

			if (inputValidator() == true)
			{
				using (SqlConnection sqc = new SqlConnection(connString))
				{
					if (isFemaleRb.Checked)
						gender = "Female";
					sqc.Open();
					string query = "update  administratorTb set firstName = '"+firstNameTxtB.Text.Trim()+"' ,fatherName=  '"+fatherNameTxtB.Text.Trim()+"',lastName =  '"+LastNameTxtB.Text.Trim()+"' , gender = '"+gender+"', contact = "+int.Parse(contactTxtB.Text.Trim())+", address = '"+ addressTxtB.Text.Trim() + "',city = '"+ cityTxtB.Text.Trim() + "', country = '"+countryTxtB.Text.Trim()+ "' where Id = " + AccountId + " ";

					SqlCommand cmd = new SqlCommand(query, sqc);
					cmd.ExecuteNonQuery();

					sqc.Close();
					MessageBox.Show("Update was successfull !!! ", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

					userNameTxtB.Text = passwordTxtB.Text = firstNameTxtB.Text = fatherNameTxtB.Text =  LastNameTxtB.Text = addressTxtB.Text = contactTxtB.Text = countryTxtB.Text = cityTxtB.Text = confirmPasswordTxtB.Text = "";
				}
			}
		}

		private void contactTxtB_TextChanged(object sender, EventArgs e)
		{

		}
	}
}
