﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpProject
{
	
	public partial class AdminForm : Form
	{
		private Form activeForm;
		static string AccountUserName;

		public static void setUserName(string accountUserName)
		{
			AccountUserName = accountUserName;
		}
		private void openChildForm(Form childForm, object btnSender)
		{
			

			if (activeForm != null)
			{
				activeForm.Close();
			}
			activeForm = childForm;
			childForm.TopLevel = false;
			childForm.FormBorderStyle = FormBorderStyle.None;
			childForm.Dock = DockStyle.Fill;
			this.windowContentPane.Controls.Add(childForm);
			this.windowContentPane.Tag = childForm;
			childForm.BringToFront();
			childForm.Show();
			contentPaneName.Text = childForm.Text;

		}
		
		public AdminForm()
		{
			InitializeComponent();
		}
		public static void formhider()
		{
			
		}

	
		private void label1_Click(object sender, EventArgs e)
		{

		}

		private void panel3_Paint(object sender, PaintEventArgs e)
		{

		}

		private void AdminForm_Load(object sender, EventArgs e)
		{
			userNameLbl.Text = AccountUserName;
			openChildForm(new Forms.homeForm(), sender);

		}
		private void button1_Click(object sender, EventArgs e)
		{

		}

		private void button2_Click(object sender, EventArgs e)
		{
			openChildForm(new Forms.applicationsForm(), sender);
		}
		private void button8_Click(object sender, EventArgs e)
		{

		}
		private void vaccancyBtn_Click(object sender, EventArgs e)
		{
			openChildForm(new Forms.vaccancyForm(), sender);
		}

		private void panel2_Paint(object sender, PaintEventArgs e)
		{

		}

		private void homeBtn_Click(object sender, EventArgs e)
		{
			openChildForm(new Forms.homeForm(), sender);
		}

		private void button4_Click(object sender, EventArgs e)
		{
			openChildForm(new Forms.statusCatagoryForm(), sender);
		}

		private void button6_Click(object sender, EventArgs e)
		{
			openChildForm(new Forms.usersForm(), sender);
		}

		private void button3_Click(object sender, EventArgs e)
		{
			openChildForm(new Forms.settingsForm(), sender);
		}

		private void windowContentPane_Paint(object sender, PaintEventArgs e)
		{
			
		}

		private void panel5_Paint(object sender, PaintEventArgs e)
		{

		}

		private void userNameLbl_Click(object sender, EventArgs e)
		{

		}

		private void aboutBtn_Click(object sender, EventArgs e)
		{
			aboutSubForm.About about = new aboutSubForm.About();
			about.ShowDialog();
		}

		private void logoutBtn_Click(object sender, EventArgs e)
		{	
			Login login = new Login();
			login.Show();
			this.Hide();
			
		}
	}
}
