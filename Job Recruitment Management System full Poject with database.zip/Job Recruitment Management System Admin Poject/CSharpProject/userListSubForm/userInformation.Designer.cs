﻿
namespace CSharpProject.userListSubForm
{
	partial class userInformation
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.addressTxtB = new System.Windows.Forms.TextBox();
			this.label14 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.lastNameTxtB = new System.Windows.Forms.TextBox();
			this.contactTxtB = new System.Windows.Forms.TextBox();
			this.userNameTxtB = new System.Windows.Forms.TextBox();
			this.firstNameTxtB = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.countryTxtB = new System.Windows.Forms.TextBox();
			this.cityTxtB = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.fatherNameTxtB = new System.Windows.Forms.TextBox();
			this.updateBtn = new System.Windows.Forms.Button();
			this.register = new System.Windows.Forms.Button();
			this.maleRb = new System.Windows.Forms.RadioButton();
			this.femaleRb = new System.Windows.Forms.RadioButton();
			this.label2 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// addressTxtB
			// 
			this.addressTxtB.Location = new System.Drawing.Point(146, 306);
			this.addressTxtB.Multiline = true;
			this.addressTxtB.Name = "addressTxtB";
			this.addressTxtB.Size = new System.Drawing.Size(254, 55);
			this.addressTxtB.TabIndex = 34;
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.BackColor = System.Drawing.Color.Transparent;
			this.label14.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label14.Location = new System.Drawing.Point(39, 240);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(71, 19);
			this.label14.TabIndex = 33;
			this.label14.Text = "Contact";
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.BackColor = System.Drawing.Color.Transparent;
			this.label13.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label13.Location = new System.Drawing.Point(35, 306);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(69, 19);
			this.label13.TabIndex = 32;
			this.label13.Text = "Address";
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.BackColor = System.Drawing.Color.Transparent;
			this.label12.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label12.Location = new System.Drawing.Point(18, 33);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(97, 19);
			this.label12.TabIndex = 31;
			this.label12.Text = "User Name";
			this.label12.Click += new System.EventHandler(this.label12_Click);
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.BackColor = System.Drawing.Color.Transparent;
			this.label6.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label6.Location = new System.Drawing.Point(20, 158);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(91, 19);
			this.label6.TabIndex = 30;
			this.label6.Text = "Last Name";
			// 
			// lastNameTxtB
			// 
			this.lastNameTxtB.Location = new System.Drawing.Point(152, 157);
			this.lastNameTxtB.Name = "lastNameTxtB";
			this.lastNameTxtB.Size = new System.Drawing.Size(254, 20);
			this.lastNameTxtB.TabIndex = 29;
			// 
			// contactTxtB
			// 
			this.contactTxtB.Location = new System.Drawing.Point(152, 240);
			this.contactTxtB.Name = "contactTxtB";
			this.contactTxtB.Size = new System.Drawing.Size(254, 20);
			this.contactTxtB.TabIndex = 28;
			// 
			// userNameTxtB
			// 
			this.userNameTxtB.Location = new System.Drawing.Point(152, 34);
			this.userNameTxtB.Name = "userNameTxtB";
			this.userNameTxtB.Size = new System.Drawing.Size(254, 20);
			this.userNameTxtB.TabIndex = 27;
			// 
			// firstNameTxtB
			// 
			this.firstNameTxtB.Location = new System.Drawing.Point(152, 77);
			this.firstNameTxtB.Name = "firstNameTxtB";
			this.firstNameTxtB.Size = new System.Drawing.Size(254, 20);
			this.firstNameTxtB.TabIndex = 26;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label1.Location = new System.Drawing.Point(20, 77);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(95, 19);
			this.label1.TabIndex = 25;
			this.label1.Text = "First Name";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label3.Location = new System.Drawing.Point(44, 429);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(70, 19);
			this.label3.TabIndex = 36;
			this.label3.Text = "country";
			this.label3.Click += new System.EventHandler(this.label3_Click);
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.BackColor = System.Drawing.Color.Transparent;
			this.label4.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label4.Location = new System.Drawing.Point(44, 381);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(37, 19);
			this.label4.TabIndex = 37;
			this.label4.Text = "city";
			// 
			// countryTxtB
			// 
			this.countryTxtB.Location = new System.Drawing.Point(146, 429);
			this.countryTxtB.Name = "countryTxtB";
			this.countryTxtB.Size = new System.Drawing.Size(254, 20);
			this.countryTxtB.TabIndex = 38;
			// 
			// cityTxtB
			// 
			this.cityTxtB.Location = new System.Drawing.Point(146, 382);
			this.cityTxtB.Name = "cityTxtB";
			this.cityTxtB.Size = new System.Drawing.Size(254, 20);
			this.cityTxtB.TabIndex = 39;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.BackColor = System.Drawing.Color.Transparent;
			this.label5.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label5.Location = new System.Drawing.Point(13, 117);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(112, 19);
			this.label5.TabIndex = 41;
			this.label5.Text = "Father Name";
			// 
			// fatherNameTxtB
			// 
			this.fatherNameTxtB.Location = new System.Drawing.Point(152, 116);
			this.fatherNameTxtB.Name = "fatherNameTxtB";
			this.fatherNameTxtB.Size = new System.Drawing.Size(254, 20);
			this.fatherNameTxtB.TabIndex = 40;
			this.fatherNameTxtB.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
			// 
			// updateBtn
			// 
			this.updateBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.updateBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.updateBtn.ForeColor = System.Drawing.Color.DarkMagenta;
			this.updateBtn.Location = new System.Drawing.Point(605, 517);
			this.updateBtn.Name = "updateBtn";
			this.updateBtn.Size = new System.Drawing.Size(75, 23);
			this.updateBtn.TabIndex = 55;
			this.updateBtn.Text = "Update";
			this.updateBtn.UseVisualStyleBackColor = false;
			this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
			// 
			// register
			// 
			this.register.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
			this.register.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.register.ForeColor = System.Drawing.Color.Red;
			this.register.Location = new System.Drawing.Point(709, 517);
			this.register.Name = "register";
			this.register.Size = new System.Drawing.Size(75, 23);
			this.register.TabIndex = 54;
			this.register.Text = "Exit";
			this.register.UseVisualStyleBackColor = false;
			this.register.Click += new System.EventHandler(this.register_Click);
			// 
			// maleRb
			// 
			this.maleRb.AutoSize = true;
			this.maleRb.Location = new System.Drawing.Point(189, 202);
			this.maleRb.Name = "maleRb";
			this.maleRb.Size = new System.Drawing.Size(48, 17);
			this.maleRb.TabIndex = 56;
			this.maleRb.TabStop = true;
			this.maleRb.Text = "Male";
			this.maleRb.UseVisualStyleBackColor = true;
			// 
			// femaleRb
			// 
			this.femaleRb.AutoSize = true;
			this.femaleRb.Location = new System.Drawing.Point(267, 202);
			this.femaleRb.Name = "femaleRb";
			this.femaleRb.Size = new System.Drawing.Size(59, 17);
			this.femaleRb.TabIndex = 57;
			this.femaleRb.TabStop = true;
			this.femaleRb.Text = "Female";
			this.femaleRb.UseVisualStyleBackColor = true;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Font = new System.Drawing.Font("Maiandra GD", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label2.Location = new System.Drawing.Point(31, 200);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(67, 19);
			this.label2.TabIndex = 58;
			this.label2.Text = "Gender";
			// 
			// userInformation
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(865, 563);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.femaleRb);
			this.Controls.Add(this.maleRb);
			this.Controls.Add(this.updateBtn);
			this.Controls.Add(this.register);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.fatherNameTxtB);
			this.Controls.Add(this.cityTxtB);
			this.Controls.Add(this.countryTxtB);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.addressTxtB);
			this.Controls.Add(this.label14);
			this.Controls.Add(this.label13);
			this.Controls.Add(this.label12);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.lastNameTxtB);
			this.Controls.Add(this.contactTxtB);
			this.Controls.Add(this.userNameTxtB);
			this.Controls.Add(this.firstNameTxtB);
			this.Controls.Add(this.label1);
			this.Name = "userInformation";
			this.Text = "userInformation";
			this.Load += new System.EventHandler(this.userInformation_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox addressTxtB;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox lastNameTxtB;
		private System.Windows.Forms.TextBox contactTxtB;
		private System.Windows.Forms.TextBox userNameTxtB;
		private System.Windows.Forms.TextBox firstNameTxtB;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox countryTxtB;
		private System.Windows.Forms.TextBox cityTxtB;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox fatherNameTxtB;
		private System.Windows.Forms.Button updateBtn;
		private System.Windows.Forms.Button register;
		private System.Windows.Forms.RadioButton maleRb;
		private System.Windows.Forms.RadioButton femaleRb;
		private System.Windows.Forms.Label label2;
	}
}