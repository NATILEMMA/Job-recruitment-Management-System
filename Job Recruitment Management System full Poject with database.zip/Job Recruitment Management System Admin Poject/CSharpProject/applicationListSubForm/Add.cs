﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.IO;

namespace CSharpProject.applicationListSubForm
{
	public partial class Add : Form
	{
		SqlConnection conn;
		SqlCommand scmd;
		SqlDataAdapter sda;
		String connString = @"Data Source=ናቲ;Initial Catalog=formloginDB;Integrated Security=True";
		string Gender = "Male";
		string Status = "new";
		String JobTitle, Company;
		int VaccancyId;
		string file;
		string fileName;
		string dest;

		public Add(String JobTitle, String Company, int VaccancyId)
		{
			this.JobTitle = JobTitle;
			this.Company = Company;
			this.VaccancyId = VaccancyId;
			
			InitializeComponent();
		}

		

		private void label10_Click(object sender, EventArgs e)
		{

		}

		private void textBox10_TextChanged(object sender, EventArgs e)
		{

		}

		private void textBox5_TextChanged(object sender, EventArgs e)
		{

		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		private void radioButton1_CheckedChanged(object sender, EventArgs e)
		{
			Gender = "Male";
		}

		private void radioButton2_CheckedChanged(object sender, EventArgs e)
		{
			Gender = "Female";
		}

		private void textBox9_TextChanged(object sender, EventArgs e)
		{

		}

		private void textBox7_TextChanged(object sender, EventArgs e)
		{

		}

		private void textBox6_TextChanged(object sender, EventArgs e)
		{

		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{

		}

		private void label12_Click(object sender, EventArgs e)
		{

		}

		private void label11_Click(object sender, EventArgs e)
		{

		}

		private void label9_Click(object sender, EventArgs e)
		{

		}

		private void label8_Click(object sender, EventArgs e)
		{

		}

		private void label7_Click(object sender, EventArgs e)
		{

		}

		private void label1_Click(object sender, EventArgs e)
		{

		}

		

		private void Add_Load(object sender, EventArgs e)
		{
			jobTitlelbl.Text = JobTitle;
			companyLbl.Text = Company;
			vaccancyIdLbl.Text = VaccancyId.ToString();
			isMaleRb.Checked = true;

		}

		private void emailTb_Validating_1(object sender, CancelEventArgs e)
		{
			emailValidator();
		}
		public bool emailValidator()
		{
			if (string.IsNullOrEmpty(emailTb.Text))
			{
				errorProvider1.SetError(emailTb, "This box should not be empty!!!");
				return false;
			}
			else if ((emailTb.Text.IndexOf("@")) == -1)
			{

				errorProvider1.SetError(emailTb, " The email provided should contain '@' symbole");
				return false;
			}
			else
			{

				errorProvider1.SetError(emailTb, null);
				return true;
			}
		}

		public bool coverletterValidator()
		{
			//cover letter validating
			if (string.IsNullOrEmpty(coverLetterTb.Text))
			{

				errorProvider1.SetError(coverLetterTb, "This box should not be empty");
				return false;
			}
			else
			{

				errorProvider1.SetError(coverLetterTb, null);
				return true;
			}

		}
		public bool filePathValidator()
		{
			// file path validating

			if (string.IsNullOrEmpty(filePathTb.Text))
			{
				errorProvider1.SetError(filePathTb, "This box should not be empty");
				return false;
			}
			else if (!((filePathTb.Text.EndsWith(".pdf")) || (filePathTb.Text.EndsWith(".PDF"))))
			{
				errorProvider1.SetError(filePathTb, "The file selected should be in '.pdf' format!!!");
				return false;
			}
			else
			{
				errorProvider1.SetError(filePathTb, null);
				return true;
			}

		}

		private void coverLetterTb_Validating_1(object sender, CancelEventArgs e)
		{
			coverletterValidator();
		}

		private void filePathTb_TextChanged(object sender, EventArgs e)
		{

		}

		private void filePathTb_Validating_1(object sender, CancelEventArgs e)
		{
			filePathValidator();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			//submit button
			
			if (inputValidator())
			{

				using (SqlConnection sqc = new SqlConnection(connString))
				{

					sqc.Open();

					SqlCommand cmd = new SqlCommand("standardPInsertApplicationsForm", sqc);
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.Parameters.AddWithValue("@firstName", firstNameTb.Text.Trim());
					cmd.Parameters.AddWithValue("@fatherName", fatherNameTb.Text.Trim());
					cmd.Parameters.AddWithValue("@lastName", lastNameTb.Text.Trim());
					cmd.Parameters.AddWithValue("@gender", Gender);
					cmd.Parameters.AddWithValue("@email", emailTb.Text.Trim());
					cmd.Parameters.AddWithValue("@contactPhoneNumber", phoneNumberTb.Text.Trim());
					cmd.Parameters.AddWithValue("@address", addressTb.Text.Trim());
					cmd.Parameters.AddWithValue("@coverLetter", coverLetterTb.Text.Trim());
					cmd.Parameters.AddWithValue("@status", Status.Trim());
					cmd.Parameters.AddWithValue("@position", jobTitlelbl.Text.Trim());
					cmd.Parameters.AddWithValue("@company", companyLbl.Text.Trim());
					cmd.Parameters.AddWithValue("@JobTitle", jobTitlelbl.Text.Trim());
					cmd.Parameters.AddWithValue("@VaccancyId", int.Parse(vaccancyIdLbl.Text.Trim()));
					cmd.Parameters.AddWithValue("@fileName", fileName);
					cmd.Parameters.AddWithValue("@filePath", dest);
					cmd.Parameters.AddWithValue("@Mail", "No Mail.");




					cmd.ExecuteNonQuery();

					sqc.Close();
					MessageBox.Show("Application submition was successfull !!! ", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

					firstNameTb.Clear();
					fatherNameTb.Clear();
					firstNameTb.Focus();



					firstNameTb.Text = fatherNameTb.Text = lastNameTb.Text = emailTb.Text = addressTb.Text = coverLetterTb.Text = "";
					this.Close();
				}
			}
		}
		private void StoreFile()
		{
			File.Copy(file, dest, true);
		}

		public bool inputValidator()
		{
			bool emailVerified = emailValidator();
			bool filepathVerified = filePathValidator();
			bool coverletterVerified = coverletterValidator();
			bool firstNameVerified = firstNameValidator();
			bool fatherNameVerified = fatherNameValidator();
			bool lastNameVerified = lastNameValidator();
			bool phoneNumberVerified = phoneNumberValidator();
			bool addressVerified = addressValidator();
			if (emailVerified == true && filepathVerified == true && coverletterVerified == true && firstNameVerified == true && fatherNameVerified == true && lastNameVerified == true && addressVerified == true && phoneNumberVerified == true)
				return true;
			else
				return false;
		}

		private void button2_Click(object sender, EventArgs e)
		{
			//browse button
			DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog.
			if (result == DialogResult.OK) // Test result.
			{
				file = openFileDialog1.FileName;

				filePathTb.Text = file;

				string[] f = file.Split('\\');
				// to get the only file name
				fileName = f[(f.Length) - 1];
				dest = @"C:\Users\NatPro\source\repos\CSharpProject\Resume\" + fileName;
			}
		}

		private bool firstNameValidator()
		{
			//cover letter validating
			if (string.IsNullOrEmpty(firstNameTb.Text))
			{

				errorProvider1.SetError(firstNameTb, "This box should not be empty");
				return false;
			}
			else
			{

				errorProvider1.SetError(firstNameTb, null);
				return true;
			}

		}
		private void firstNameTb_Validating(object sender, CancelEventArgs e)
		{
			firstNameValidator();
		}
		private bool fatherNameValidator()
		{
			//cover letter validating
			if (string.IsNullOrEmpty(fatherNameTb.Text))
			{

				errorProvider1.SetError(fatherNameTb, "This box should not be empty");
				return false;
			}
			else
			{

				errorProvider1.SetError(fatherNameTb, null);
				return true;
			}

		}
		private void fatherNameTb_Validating(object sender, CancelEventArgs e)
		{
			fatherNameValidator();
		}

		private bool lastNameValidator()
		{
			//cover letter validating
			if (string.IsNullOrEmpty(lastNameTb.Text))
			{

				errorProvider1.SetError(lastNameTb, "This box should not be empty");
				return false;
			}
			else
			{

				errorProvider1.SetError(lastNameTb, null);
				return true;
			}

		}
		private void lastNameTb_Validating(object sender, CancelEventArgs e)
		{
			lastNameValidator();
		}

		private bool phoneNumberValidator()
		{
			Int32 SampleInteger;
			
			if (string.IsNullOrEmpty(phoneNumberTb.Text))
			{

				errorProvider1.SetError(phoneNumberTb, "This box should not be empty");
				return false;
			}
			else if (!(int.TryParse(phoneNumberTb.Text, out SampleInteger)))
			{
				errorProvider1.SetError(phoneNumberTb, "The phone number must be valid!!!");
				return false;
			}
			else
			{

				errorProvider1.SetError(phoneNumberTb, null);
				return true;
			}

		}
		private void phoneNumberTb_Validating(object sender, CancelEventArgs e)
		{
			phoneNumberValidator();
		}

		private void addressTb_TextChanged(object sender, EventArgs e)
		{
			
		}

		private bool addressValidator()
		{
			//cover letter validating
			if (string.IsNullOrEmpty(addressTb.Text))
			{

				errorProvider1.SetError(addressTb, "This box should not be empty");
				return false;
			}
			else
			{

				errorProvider1.SetError(addressTb, null);
				return true;
			}

		}
		private void addressTb_Validating(object sender, CancelEventArgs e)
		{
			addressValidator();
		}

		private void label14_Click(object sender, EventArgs e)
		{

		}
	}
}
