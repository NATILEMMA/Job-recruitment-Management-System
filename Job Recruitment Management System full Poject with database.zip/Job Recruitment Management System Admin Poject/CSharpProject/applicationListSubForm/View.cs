﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CSharpProject.applicationListSubForm
{
	public partial class View : Form
	{
		SqlConnection conn;
		SqlCommand cmd;
		SqlDataAdapter sda;
		SqlDataReader dreader;
		String connString = @"Data Source=ናቲ;Initial Catalog=formloginDB;Integrated Security=True";
		string Gender = "";
		string Status = "new";
		int selectedId;
		String senderForm;
		string filePath;
		public View(int selectedId, String senderForm)
		{
			InitializeComponent();
			this.selectedId = selectedId;
			this.senderForm = senderForm;
		}



		private void positionComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		private void isMaleRb_CheckedChanged(object sender, EventArgs e)
		{

		}

		private void isFemalRb_CheckedChanged(object sender, EventArgs e)
		{

		}

		private void register_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void View_Load(object sender, EventArgs e)
		{
			if (senderForm == "View")
				updateBtn.Visible = false;


			conn = new SqlConnection(connString);
			conn.Open();
			cmd = new SqlCommand("select* from applicationsTb where Id =" + selectedId + " ", conn);
			
			try
			{
				dreader = cmd.ExecuteReader();
				if (dreader.Read())
				{

					firstNameTb.Text = dreader[0].ToString().Trim();
					fatherNameTb.Text = dreader[1].ToString().Trim();
					lastNameTb.Text = dreader[2].ToString().Trim();
					Gender = dreader[3].ToString().Trim();
					email.Text = dreader[4].ToString().Trim();
					phoneNumberTb.Text = dreader[5].ToString().Trim();
					addressTb.Text = dreader[6].ToString().Trim();
					coverLetterTb.Text = dreader[7].ToString().Trim();
					//Status.Text = dreader[8].ToString();
					positionTb.Text = dreader[9].ToString().Trim();
					filePath = dreader[15].ToString();

					if (Gender == "Male")
						isMaleRb.Checked = true;
					else if (Gender == "Female")
						isFemalRb.Checked = true;
				}
			}
			catch (Exception)
			{
				MessageBox.Show(" not record");
			}
			finally { conn.Close(); }
			
		}
	

		private void button1_Click(object sender, EventArgs e)
		{


			if (isMaleRb.Checked == true)
				Gender = "Male";
			else if (isFemalRb.Checked == true)
				Gender = "Female";
			conn = new SqlConnection(connString);
			conn.Open();
			cmd = new SqlCommand("update applicationsTb set firstName='" + firstNameTb.Text + "',fatherName = '" + fatherNameTb.Text + "', lastName=' " + lastNameTb.Text + "', gender=' " + Gender + "', email =' " + email.Text + "', contactPhoneNumber =' " + phoneNumberTb.Text + "' ,address= '" + addressTb.Text + "',coverLetter= '" + coverLetterTb.Text + "' where Id =" +selectedId + " ", conn);
			try
			{
				cmd.ExecuteNonQuery();
				MessageBox.Show("updated...");
			}
			catch (Exception)
			{
				MessageBox.Show(" Not updated!!!! ");
			}
			finally { conn.Close(); }
		}

		private void button1_Click_1(object sender, EventArgs e)
		{
			OpenResume openresumeForm = new OpenResume(selectedId,filePath);
			openresumeForm.ShowDialog();
		}
	}
}

