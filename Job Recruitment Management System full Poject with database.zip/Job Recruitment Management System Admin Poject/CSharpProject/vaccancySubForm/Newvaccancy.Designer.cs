﻿
namespace CSharpProject.vaccancySubForm
{
	partial class New_vaccancy
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtCompany = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.txtDiscription = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.txtJobTitle = new System.Windows.Forms.TextBox();
			this.txtJobType = new System.Windows.Forms.TextBox();
			this.txtSalary = new System.Windows.Forms.TextBox();
			this.btnSave = new System.Windows.Forms.Button();
			this.deadLinePicker = new System.Windows.Forms.DateTimePicker();
			this.button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// txtCompany
			// 
			this.txtCompany.Location = new System.Drawing.Point(44, 149);
			this.txtCompany.Multiline = true;
			this.txtCompany.Name = "txtCompany";
			this.txtCompany.Size = new System.Drawing.Size(254, 25);
			this.txtCompany.TabIndex = 50;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.Location = new System.Drawing.Point(41, 38);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(65, 16);
			this.label6.TabIndex = 34;
			this.label6.Text = "Job Title";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.Location = new System.Drawing.Point(41, 130);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(71, 16);
			this.label5.TabIndex = 33;
			this.label5.Text = "Company";
			// 
			// txtDiscription
			// 
			this.txtDiscription.Location = new System.Drawing.Point(44, 334);
			this.txtDiscription.Multiline = true;
			this.txtDiscription.Name = "txtDiscription";
			this.txtDiscription.Size = new System.Drawing.Size(254, 104);
			this.txtDiscription.TabIndex = 54;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(41, 315);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(0, 16);
			this.label1.TabIndex = 52;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(342, 130);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(67, 16);
			this.label2.TabIndex = 55;
			this.label2.Text = "DeadLine";
			this.label2.Click += new System.EventHandler(this.label2_Click);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.Location = new System.Drawing.Point(41, 223);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(69, 16);
			this.label3.TabIndex = 58;
			this.label3.Text = "Job Type";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.Location = new System.Drawing.Point(45, 315);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(79, 16);
			this.label4.TabIndex = 59;
			this.label4.Text = "Discription";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Font = new System.Drawing.Font("Maiandra GD", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.Location = new System.Drawing.Point(342, 38);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(47, 16);
			this.label7.TabIndex = 60;
			this.label7.Text = "Salary";
			this.label7.Click += new System.EventHandler(this.label7_Click);
			// 
			// txtJobTitle
			// 
			this.txtJobTitle.Location = new System.Drawing.Point(44, 57);
			this.txtJobTitle.Multiline = true;
			this.txtJobTitle.Name = "txtJobTitle";
			this.txtJobTitle.Size = new System.Drawing.Size(254, 25);
			this.txtJobTitle.TabIndex = 61;
			// 
			// txtJobType
			// 
			this.txtJobType.Location = new System.Drawing.Point(44, 252);
			this.txtJobType.Multiline = true;
			this.txtJobType.Name = "txtJobType";
			this.txtJobType.Size = new System.Drawing.Size(254, 25);
			this.txtJobType.TabIndex = 62;
			// 
			// txtSalary
			// 
			this.txtSalary.Location = new System.Drawing.Point(345, 57);
			this.txtSalary.Multiline = true;
			this.txtSalary.Name = "txtSalary";
			this.txtSalary.Size = new System.Drawing.Size(254, 25);
			this.txtSalary.TabIndex = 63;
			// 
			// btnSave
			// 
			this.btnSave.Location = new System.Drawing.Point(44, 456);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(75, 23);
			this.btnSave.TabIndex = 65;
			this.btnSave.Text = "Save";
			this.btnSave.UseVisualStyleBackColor = true;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// deadLinePicker
			// 
			this.deadLinePicker.Location = new System.Drawing.Point(345, 154);
			this.deadLinePicker.Name = "deadLinePicker";
			this.deadLinePicker.Size = new System.Drawing.Size(200, 20);
			this.deadLinePicker.TabIndex = 66;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(524, 456);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 67;
			this.button1.Text = "Exit";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// New_vaccancy
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(631, 491);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.deadLinePicker);
			this.Controls.Add(this.btnSave);
			this.Controls.Add(this.txtSalary);
			this.Controls.Add(this.txtJobType);
			this.Controls.Add(this.txtJobTitle);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txtDiscription);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtCompany);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Name = "New_vaccancy";
			this.Text = "New_vaccancy";
			this.Load += new System.EventHandler(this.New_vaccancy_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.TextBox txtCompany;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox txtDiscription;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox txtJobTitle;
		private System.Windows.Forms.TextBox txtJobType;
		private System.Windows.Forms.TextBox txtSalary;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.DateTimePicker deadLinePicker;
		private System.Windows.Forms.Button button1;
	}
}