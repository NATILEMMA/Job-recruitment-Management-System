﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CSharpProject.vaccancySubForm
{
	public partial class New_vaccancy : Form
	{

		SqlConnection conn;
		SqlCommand scmd;
		SqlDataAdapter sda;
		String connString = @"Data Source=ናቲ;Initial Catalog=formloginDB;Integrated Security=True";
		string Gender = "";
		string Status = "new";
		public New_vaccancy()
		{
			InitializeComponent();
		}

		private void New_vaccancy_Load(object sender, EventArgs e)
		{

		}

		private void label2_Click(object sender, EventArgs e)
		{

		}

		private void label7_Click(object sender, EventArgs e)
		{

		}

		private void btnSave_Click(object sender, EventArgs e)
		{

			using (SqlConnection sqc = new SqlConnection(connString))
			{

				sqc.Open();

				SqlCommand cmd = new SqlCommand("standardPInsertVaccancyForm", sqc);
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.Parameters.AddWithValue("@JobTitle", txtJobTitle.Text.Trim());
				cmd.Parameters.AddWithValue("@Company", txtCompany.Text.Trim());
				cmd.Parameters.AddWithValue("@JobType", txtJobType.Text.Trim());
				cmd.Parameters.AddWithValue("@Discription",txtDiscription.Text.Trim());
				cmd.Parameters.AddWithValue("@Salary",txtSalary.Text.Trim());
				cmd.Parameters.AddWithValue("@Deadline",deadLinePicker.Text.Trim());
				

				cmd.ExecuteNonQuery();

				sqc.Close();
				MessageBox.Show("vaccancy submition was successfull !!! ", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

				txtJobTitle.Text = txtCompany.Text = txtJobType.Text = txtDiscription.Text = txtSalary.Text = deadLinePicker.Text = "";
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
	

