﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpProject
{
	public partial class OpenResume : Form
	{
		int selectedId;
		string filePath;
		public OpenResume(int selectedId,String filePath)
		{
			this.selectedId = selectedId;
			this.filePath = filePath;
			InitializeComponent();
		}

		private void OpenResume_Load(object sender, EventArgs e)
		{

			axAcroPDF1.src = filePath;
		}
	}
}
