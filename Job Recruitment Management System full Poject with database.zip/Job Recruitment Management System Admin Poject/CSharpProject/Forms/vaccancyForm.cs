﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CSharpProject.Forms
{
	public partial class vaccancyForm : Form
	{
		SqlConnection conn;
		SqlCommand cmd;
		SqlDataAdapter sda;
		SqlDataReader Reader;
		DataTable dt;
		public vaccancyForm()
		{
			InitializeComponent();
		}

		private void txtSearch_TextChanged(object sender, EventArgs e)
		{

		}

		private void vaccancyForm_Load(object sender, EventArgs e)
		{
			idRb.Checked = true;
		}

		private void button2_Click(object sender, EventArgs e)
		{
			using (vaccancySubForm.New_vaccancy add = new vaccancySubForm.New_vaccancy())
			{
				add.ShowDialog();
			}
		}

		public int selectedRowIdFromGridView()
		{
			String noRowData = "There is no data record in the row selected!!!";
			String noRowSelected = "No row was selected! Please select a row from the table.";

			if (this.vaccancyDGV.SelectedRows.Count == 1)
			{
				try
				{
					int rowId = int.Parse(vaccancyDGV.CurrentRow.Cells["Id"].Value.ToString());
					errorLbl.Visible = false;
					return rowId;

				}
				catch (Exception)
				{
					errorLbl.Text = noRowData;
					errorLbl.Visible = true;
					return -1;
				}

			}
			else
			{
				errorLbl.Text = noRowSelected;
				errorLbl.Visible = true;
				return -1;
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			int selectedRowId = selectedRowIdFromGridView();
			String senderForm = "edit";
			if (selectedRowId != -1)
			{
				using (vaccancySubForm.Information edit = new vaccancySubForm.Information(selectedRowId, senderForm))
				{
					edit.ShowDialog();
				}
			}

		}

		private void button5_Click(object sender, EventArgs e)
		{
			int selectedRowId = selectedRowIdFromGridView();
			String senderForm = "view";
			if (selectedRowId != -1)
			{
				using (vaccancySubForm.Information view = new vaccancySubForm.Information(selectedRowId, senderForm))
				{
					view.ShowDialog();
				}
			}
		}

		private void deleteBtn_Click(object sender, EventArgs e)
		{

			int rowId = selectedRowIdFromGridView();
			if (rowId != -1)
			{
				if (MessageBox.Show("Do you want to delete the vaccancy data with id: " + rowId + "", "Delete record", MessageBoxButtons.YesNo) == DialogResult.Yes)
				{

					conn = new SqlConnection("Data Source = ናቲ; Initial Catalog = formloginDB; Integrated Security = True");
					conn.Open();

					cmd = new SqlCommand("delete from vaccancyTb where Id = " + rowId + " ", conn);
					cmd.ExecuteNonQuery();
					MessageBox.Show("Deleted.. successfully of row with Id: " + rowId + "");
					dt = new DataTable();
					sda.Fill(dt);
					vaccancyDGV.DataSource = dt;
					conn.Close();
				}
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			conn = new SqlConnection("Data Source = ናቲ; Initial Catalog = formloginDB; Integrated Security = True");
			conn.Open();
			sda = new SqlDataAdapter(@"Select JobTitle , Company, Jobtype, Id from vaccancyTb  ", conn);
			dt = new DataTable();
			sda.Fill(dt);

			vaccancyDGV.DataSource = dt;
			conn.Close();
		}

		private void btnSearch_Click(object sender, EventArgs e)
		{
			if (idRb.Checked == true)
			{
				try
				{
					conn = new SqlConnection("Data Source = ናቲ; Initial Catalog = formloginDB; Integrated Security = True");
					conn.Open();
					sda = new SqlDataAdapter($"Select JobTitle , Company, Jobtype, Id from vaccancyTb where Id  = {int.Parse(txtSearch.Text.Trim())}", conn);
					dt = new DataTable();
					sda.Fill(dt);

					vaccancyDGV.DataSource = dt;

					dt = new DataTable();
					sda.Fill(dt);
					vaccancyDGV.DataSource = dt;
					if (dt.Rows.Count < 1)
					{
						MessageBox.Show("No record found! Make sure you use the right Id.");
						conn.Close();
					}
					else
					{

						conn.Close();
					}



				}
				catch (Exception)
				{
					MessageBox.Show("No record found!");
				}
				finally { conn.Close(); }
			}

			else if (jobTitleRb.Checked == true)
			{
				try
				{
					conn = new SqlConnection("Data Source = ናቲ; Initial Catalog = formloginDB; Integrated Security = True");
					conn.Open();
					sda = new SqlDataAdapter($"Select JobTitle , Company, Jobtype, Id from vaccancyTb where JobTitle = '" + txtSearch.Text.Trim() + "'", conn);
					dt = new DataTable();
					sda.Fill(dt);
					vaccancyDGV.DataSource = dt;
					if (dt.Rows.Count < 1)
					{
						MessageBox.Show("No record found! Make sure you use Capital letter for the first letter.");
						conn.Close();
					}
					else
					{

						conn.Close();
					}

				}
				catch (Exception)
				{
					MessageBox.Show("No record found! Make sure you use Capital letter for the first letter.");
				}
				finally { conn.Close(); }
			}

		}

		private void panel2_Paint(object sender, PaintEventArgs e)
		{

		}

		private void panel3_Paint(object sender, PaintEventArgs e)
		{

		}

		private void button4_Click(object sender, EventArgs e)
		{
			String JobTitle, Company;
			int VaccancyId;
			int rowId = selectedRowIdFromGridView();
			conn = new SqlConnection("Data Source = ናቲ; Initial Catalog = formloginDB; Integrated Security = True");
			conn.Open();
			cmd = new SqlCommand("select JobTitle,Company,Id from vaccancyTb where Id =" + rowId + " ", conn);



			Reader = cmd.ExecuteReader();
			if (Reader.Read())
			{
				JobTitle = Reader[0].ToString();
				Company = Reader[1].ToString();
				VaccancyId = int.Parse(Reader[2].ToString());

				using (applicationListSubForm.Add addNew = new applicationListSubForm.Add(JobTitle, Company, VaccancyId))
				{
					addNew.ShowDialog();
				}
			}
		}
	}
}
	

