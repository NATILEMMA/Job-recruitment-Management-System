﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CSharpProject.Forms
{
	public partial class usersForm : Form
	{
		SqlConnection conn;
		SqlCommand cmd;
		SqlDataAdapter sda;
		DataTable dt;
		public usersForm()
		{
			InitializeComponent();
		}

		public void loadDGV()
		{

			conn = new SqlConnection("Data Source = ናቲ; Initial Catalog = formloginDB; Integrated Security = True");
			conn.Open();
			sda = new SqlDataAdapter(@"Select userName,firstName,fatherName, lastName ,contact,city, Id from userTb ", conn);
			dt = new DataTable();
			sda.Fill(dt);
			usersDGV.DataSource = dt;
			conn.Close();
		}
		private void button1_Click(object sender, EventArgs e)
		{

			loadDGV();
		}

		public int selectedRowIdFromGridView()
		{
			String noRowData = "There is no data record in the row selected!!!";
			String noRowSelected = "No row was selected! Please select a row from the table.";

			if (this.usersDGV.SelectedRows.Count == 1)
			{
				try
				{
					int rowId = int.Parse(usersDGV.CurrentRow.Cells["Id"].Value.ToString());
					errorLbl.Visible = false;
					return rowId;

				}
				catch (Exception)
				{
					errorLbl.Text = noRowData;
					errorLbl.Visible = true;
					return -1;
				}

			}
			else
			{
				errorLbl.Text = noRowSelected;
				errorLbl.Visible = true;
				return -1;
			}
		}

		private void usersForm_Load(object sender, EventArgs e)
		{
			loadDGV();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			String senderForm = "Edit";
			//edit

			int selectedRowId = selectedRowIdFromGridView();
			if (selectedRowId != -1)
			{
				using (userListSubForm.userInformation edit = new userListSubForm.userInformation(selectedRowId, senderForm))
				{
					edit.ShowDialog();
				}
			}
		}

		private void deleteBtn_Click(object sender, EventArgs e)
		{

			int rowId = selectedRowIdFromGridView();
			if (rowId != -1)
			{
				if (MessageBox.Show("Do you want to delete the user  with id: " + rowId + "", "Delete record", MessageBoxButtons.YesNo) == DialogResult.Yes)
				{

					conn = new SqlConnection("Data Source = ናቲ; Initial Catalog = formloginDB; Integrated Security = True");
					conn.Open();

					cmd = new SqlCommand("delete from userTb where Id = " + rowId + " ", conn);
					cmd.ExecuteNonQuery();
					MessageBox.Show("Deleted.. successfully of row with Id: " + rowId + "");
					loadDGV();
					conn.Close();
				}
			}
		}

		private void button5_Click(object sender, EventArgs e)
		{
			//view
			int selectedRowId = selectedRowIdFromGridView();
			String senderForm = "View";
			if (selectedRowId != -1)
			{
				using (userListSubForm.userInformation view = new userListSubForm.userInformation(selectedRowId, senderForm))
				{
					view.ShowDialog();
				}
			}
		}

		private void btnSearch_Click(object sender, EventArgs e)
		{
			//Search button
			if (idRb.Checked == true)
			{
				try
				{
					conn = new SqlConnection("Data Source = ናቲ; Initial Catalog = formloginDB; Integrated Security = True");
					conn.Open();
					sda = new SqlDataAdapter($"Select userName,firstName,fatherName,lastName ,contact,city, Id from userTb where Id = {int.Parse(txtSearch.Text.Trim())}", conn);
					dt = new DataTable();
					sda.Fill(dt);

					usersDGV.DataSource = dt;

					dt = new DataTable();
					sda.Fill(dt);
					usersDGV.DataSource = dt;
					if (dt.Rows.Count < 1)
					{
						MessageBox.Show("No record found! Make sure you use the right Id.");
						conn.Close();
					}
					else
					{

						conn.Close();
					}
				}
				catch (Exception)
				{
					MessageBox.Show("No record found!");
				}
				finally { conn.Close(); }
			}

			else if (nameRb.Checked == true)
			{
				try
				{
					conn = new SqlConnection("Data Source = ናቲ; Initial Catalog = formloginDB; Integrated Security = True");
					conn.Open();
					sda = new SqlDataAdapter($"Select userName,firstName,fatherName,lastName ,contact,city, Id from userTb where firstName = '" + txtSearch.Text.Trim() + "'", conn);
					dt = new DataTable();
					sda.Fill(dt);
					usersDGV.DataSource = dt;
					if (dt.Rows.Count < 1)
					{
						MessageBox.Show("No record found! Make sure you use Capital letter for the first letter.");
						conn.Close();
					}
					else
					{
						conn.Close();
					}

				}
				catch (Exception)
				{
					MessageBox.Show("No record found! Make sure you use Capital letter for the first letter.");
				}
				finally { conn.Close(); }
			}
		}

		private void usersDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{

		}
	}
}
