﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CSharpProject.Forms
{

	public partial class applicationsForm : Form
	{
		SqlConnection conn;
		SqlCommand cmd;
		SqlDataAdapter sda;
		DataTable dt;
		
		public applicationsForm()
		{
			InitializeComponent();
		}
		

		private void button1_Click(object sender, EventArgs e)
		{
			conn = new SqlConnection("Data Source = ናቲ; Initial Catalog = formloginDB; Integrated Security = True");
			conn.Open();
			sda = new SqlDataAdapter(@"Select firstName, fatherName, position, Status ,Id from applicationsTb ", conn);
			dt = new DataTable();
			sda.Fill(dt);

			applicaitonsDGV.DataSource = dt;
			conn.Close();
		}


		private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{

		}

		private void button3_Click(object sender, EventArgs e)
		{
			String senderForm = "Edit";
			//edit

			int selectedRowId = selectedRowIdFromGridView();
			if (selectedRowId != -1)
			{
				using (applicationListSubForm.View edit = new applicationListSubForm.View(selectedRowId, senderForm))
				{
					edit.ShowDialog();
				}
			}
		}


		private void button4_Click(object sender, EventArgs e)
		{
			int rowId = selectedRowIdFromGridView();
		    if(rowId != -1) { 
			if (MessageBox.Show("Do you want to delete the application data with id: " + rowId + "", "Delete record", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{

						conn = new SqlConnection("Data Source = ናቲ; Initial Catalog = formloginDB; Integrated Security = True");
						conn.Open();
		
						cmd = new SqlCommand("delete from applicationsTb where Id = " + rowId + " ", conn);
						cmd.ExecuteNonQuery();
						MessageBox.Show("Deleted.. successfully of row with Id: " + rowId + "");
						dt = new DataTable();
						sda.Fill(dt);
						applicaitonsDGV.DataSource = dt;
						conn.Close();
			}
			}
		}
			
		

		public int selectedRowIdFromGridView()
		{
			String noRowData = "There is no data record in the row selected!!!";
			String noRowSelected = "No row was selected! Please select a row from the table.";

			if (this.applicaitonsDGV.SelectedRows.Count == 1)	{
				try{
					int rowId = int.Parse(applicaitonsDGV.CurrentRow.Cells["Id"].Value.ToString());
					errorLbl.Visible = false;
					return rowId;

				}
				catch (Exception){
					errorLbl.Text = noRowData;
					errorLbl.Visible = true;
					return -1;
				}
				
			}
			else{
				errorLbl.Text = noRowSelected;
				errorLbl.Visible = true;
				return -1;
			}
		}



		private void button5_Click(object sender, EventArgs e)
		{
			int selectedRowId = selectedRowIdFromGridView();
			String senderForm = "View";
			if (selectedRowId != -1)
			{
				using (applicationListSubForm.View view = new applicationListSubForm.View( selectedRowId, senderForm)){
						 view.ShowDialog();
				}
			}
		}

		private void errorLbl_Click(object sender, EventArgs e)
		{
			
		}

		private void applicationsForm_Load(object sender, EventArgs e)
		{
			idRb.Checked = true;
		}

		private void panel1_Paint(object sender, PaintEventArgs e)
		{

		}

		private void button4_Click_1(object sender, EventArgs e)
		{
			//Search button
			if(idRb.Checked == true)
			{
				try
				{
					conn = new SqlConnection("Data Source = ናቲ; Initial Catalog = formloginDB; Integrated Security = True");
					conn.Open();
					sda = new SqlDataAdapter($"Select firstName, fatherName, position, Status ,Id from applicationsTb where Id = {int.Parse(txtSearch.Text.Trim())}", conn);
					dt = new DataTable();
					sda.Fill(dt);

					applicaitonsDGV.DataSource = dt;

					dt = new DataTable();
					sda.Fill(dt);
					applicaitonsDGV.DataSource = dt;
					if (dt.Rows.Count < 1)
					{
						MessageBox.Show("No record found! Make sure you use the right Id.");
						conn.Close();
					}
					else
					{

						conn.Close();
					}



				}
				catch (Exception)
				{
					MessageBox.Show("No record found!");
				}
				finally { conn.Close(); }
			}

			else if (nameRb.Checked == true)
			{
				try
				{
				conn = new SqlConnection("Data Source = ናቲ; Initial Catalog = formloginDB; Integrated Security = True");
					conn.Open();
					sda = new SqlDataAdapter($"Select firstName, fatherName, position, Status ,Id from applicationsTb where firstName = '"+txtSearch.Text.Trim()+"'", conn);
					dt = new DataTable();
					sda.Fill(dt);
					applicaitonsDGV.DataSource = dt;
					if (dt.Rows.Count <1)
					{
						MessageBox.Show("No record found! Make sure you use Capital letter for the first letter.");
						conn.Close();
					}
					else
					{
	
						conn.Close();
					}
					
			}
			catch (Exception)
			{
				MessageBox.Show("No record found! Make sure you use Capital letter for the first letter.");
			}
			finally { conn.Close(); }
		}

			else if (positionRb.Checked == true)
			{
				try
				{
					conn = new SqlConnection("Data Source = ናቲ; Initial Catalog = formloginDB; Integrated Security = True");
					conn.Open();
					sda = new SqlDataAdapter($"Select firstName, fatherName, position, Status ,Id from applicationsTb where position =  '" + txtSearch.Text.Trim()+ "'", conn);
					dt = new DataTable();
					sda.Fill(dt);
					applicaitonsDGV.DataSource = dt;
					if (dt.Rows.Count < 1)
					{
						MessageBox.Show("No record found! Make sure you use Capital letter for the first letter");
						conn.Close();
					}
					else
					{

						conn.Close();
					}
				}
				catch (Exception)
				{
					MessageBox.Show("No record found! Make sure you use Capital letter for the first letter");
				}
				finally { conn.Close(); }
			}
		}
	}
}
