﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CSharpProject.Forms
{
	public partial class settingsForm : Form
	{
		SqlConnection conn;
		SqlCommand cmd;
		SqlDataReader sdr;
		String connString = @"Data Source=ናቲ;Initial Catalog=formloginDB;Integrated Security=True";
		private static int accountId;
		public settingsForm()
		{
			InitializeComponent();
		}
		public static void setAccountId(int accountId)
		{
			settingsForm.accountId = accountId;
		}

		private void label4_Click(object sender, EventArgs e)
		{

		}

		private void panel4_Paint(object sender, PaintEventArgs e)
		{

		}

		private void button4_Click(object sender, EventArgs e)
		{
			settingsSubForm.Delete_account deleteForm = new settingsSubForm.Delete_account();
			deleteForm.ShowDialog();

		}

		private void register_Click(object sender, EventArgs e)
		{
			conn = new SqlConnection(connString);
			conn.Open();
			cmd = new SqlCommand("select  userName, password from administratorTb where Id = " + accountId + "", conn);
			sdr = cmd.ExecuteReader();

			if (confirmationPasswordTxtB.Text  != "")
			{
			 if ( sdr.Read() && confirmationPasswordTxtB.Text == sdr[1].ToString())
				{
					conn = new SqlConnection(connString);
					conn.Open();
					cmd = new SqlCommand("select  userName, password from administratorTb where Id = " + accountId + "", conn);
					sdr = cmd.ExecuteReader();
					if (sdr.Read())
					{
						if (sdr[1].ToString() == confirmationPasswordTxtB.Text.Trim())
						{
							if (MessageBox.Show("Are you sure you want to delete the account with user name: " + sdr[0].ToString() + " ", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
							{
								conn.Close();
								conn.Open();
								cmd = new SqlCommand("delete from administratorTb where Id = " + accountId + " ", conn);
								cmd.ExecuteNonQuery();
								MessageBox.Show("Deleted.. successfully of account with Id: " + accountId + "");
								conn.Close();
								ParentForm.Hide();
								Login login = new Login();
								login.Show();
							}
							conn.Close();
						}
					}
					else
					{
						MessageBox.Show("invalid attempt to read when there is no data present");
					}
				}
				else
				{
					MessageBox.Show("Password entered doesn't match account password!");
				}
			}
			else
			{
				passwordMandatoryLbl.Visible = true;
			}
		}

		private void settingsForm_Load(object sender, EventArgs e)
		{

		}

		private void button3_Click(object sender, EventArgs e)
		{
			settingsSubForm.Change_user_name_and_password change = new settingsSubForm.Change_user_name_and_password();
			change.ShowDialog();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			signUp changePersonal = new signUp(accountId);
			changePersonal.ShowDialog();
		}
	}
}
